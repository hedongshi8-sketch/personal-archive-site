using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class NinjaRogueSceneBuilder
{
    private const string ScenePath = "Assets/Scenes/NinjaRogueMode_Demo.unity";
    private const string InkRoot = "Assets/ArtPlaceholders/Ink";
    private const string CharacterRoot = "Assets/Resources/ArtPlaceholders/Characters";
    private const string WeaponRoot = "Assets/Resources/ArtPlaceholders/Weapons";
    private const string EnemyRoot = "Assets/Resources/ArtPlaceholders/Enemies";
    private const string ExternalRoot = "Assets/External/NinjaAdventure";

    [MenuItem("Ninja Rogue/Generate Demo Scene")]
    public static void GenerateDemoScene()
    {
        BuildScene();
    }

    public static void BuildScene()
    {
        EnsureFolders();
        GenerateVisualResources();

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "NinjaRogueMode_Demo";

        Sprite sky = LoadSprite($"{InkRoot}/ink_paper_sky.png");
        Sprite mist = LoadSprite($"{InkRoot}/ink_mist.png");
        Sprite farMountains = LoadSprite($"{InkRoot}/ink_far_mountains.png");
        Sprite nearMountains = LoadSprite($"{InkRoot}/ink_near_mountains.png");
        Sprite ground = LoadSprite($"{InkRoot}/ink_ground_stroke.png");
        Sprite bamboo = LoadSprite($"{InkRoot}/ink_bamboo_stroke.png");
        Sprite weaponDoorSprite = LoadSprite($"{InkRoot}/ink_weapon_gate.png");
        Sprite characterDoorSprite = LoadSprite($"{InkRoot}/ink_character_gate.png");
        Sprite spikeSprite = LoadSprite($"{InkRoot}/hazard_ground_spike.png");
        Sprite sickleSprite = LoadSprite($"{InkRoot}/hazard_hanging_sickle.png");
        Sprite shurikenSprite = LoadSprite($"{InkRoot}/hazard_flying_shuriken.png");
        Sprite boulderSprite = LoadSprite($"{InkRoot}/hazard_rolling_boulder.png");
        Sprite riftSprite = LoadSprite($"{InkRoot}/hazard_shadow_rift.png");
        Sprite moonSprite = LoadSprite($"{InkRoot}/ink_moon.png");
        Sprite altarSprite = LoadSprite($"{InkRoot}/ink_reward_altar.png");
        Sprite startNinja = Resources.Load<Sprite>("ArtPlaceholders/Characters/flame_runner");
        Sprite gruntEnemy = Resources.Load<Sprite>("ArtPlaceholders/Enemies/grunt_pig");
        Sprite eliteEnemy = Resources.Load<Sprite>("ArtPlaceholders/Enemies/elite_samurai");
        Sprite bossEnemy = Resources.Load<Sprite>("ArtPlaceholders/Enemies/boss_shadow");

        GameObject demoRoot = new GameObject("忍者秘境 Demo Root");
        GameObject manager = new GameObject("Demo Controller");
        manager.transform.SetParent(demoRoot.transform);
        NinjaRogueDemoController controller = manager.AddComponent<NinjaRogueDemoController>();

        CreateSpriteObject("宣纸底色", sky, new Vector3(1.5f, 0.25f, 4f), 43f, 11f, -55, demoRoot.transform);
        SpriteRenderer atmosphere = CreateSpriteObject("关卡氛围色", sky, new Vector3(1.5f, 0.25f, 3.8f), 43f, 11f, -54, demoRoot.transform).GetComponent<SpriteRenderer>();
        atmosphere.color = new Color(0.12f, 0.1f, 0.05f, 0.08f);
        controller.RegisterAtmosphere(atmosphere);

        CreateSpriteObject("淡月", moonSprite, new Vector3(-10.7f, 2.8f, 2.9f), 2.0f, 2.0f, -45, demoRoot.transform);
        CreateSpriteObject("远山", farMountains, new Vector3(0f, -0.65f, 3.2f), 40f, 6.0f, -40, demoRoot.transform);
        CreateSpriteObject("近山", nearMountains, new Vector3(2.0f, -1.25f, 2.6f), 40f, 5.2f, -35, demoRoot.transform);
        CreateSpriteObject("白雾", mist, new Vector3(2f, 0.25f, 2.2f), 38f, 2.4f, -30, demoRoot.transform);
        CreateSpriteObject("地面墨痕", ground, new Vector3(1.5f, -2.75f, 1.2f), 38f, 1.55f, -10, demoRoot.transform);
        CreateSpriteObject("前景地墨", ground, new Vector3(3.5f, -3.15f, 0.4f), 39f, 1.05f, 10, demoRoot.transform);
        CreateSpriteObject("上位墨痕提示", ground, new Vector3(2.2f, -1.22f, 1.18f), 32f, 0.42f, -9, demoRoot.transform);
        CreateLabel("上位", new Vector3(-12.25f, -0.72f, -0.2f), 0.07f, new Color(0.06f, 0.05f, 0.04f), demoRoot.transform);
        CreateLabel("下位", new Vector3(-12.25f, -2.12f, -0.2f), 0.07f, new Color(0.06f, 0.05f, 0.04f), demoRoot.transform);

        for (int i = 0; i < 7; i++)
        {
            float x = -13.2f + i * 5.2f;
            float height = 3.2f + (i % 3) * 0.55f;
            CreateSpriteObject($"墨竹 {i + 1}", bamboo, new Vector3(x, -0.95f, 1.8f), 0.55f, height, -18, demoRoot.transform);
        }

        Transform start = CreateMarker("玩家出生点", new Vector3(-13.5f, -2.15f, 0f), demoRoot.transform);
        controller.RegisterPlayerStart(start);

        GameObject player = CreateSpriteObject("玩家 - 角色差分显示", startNinja, start.position, 1.35f, 1.85f, 8, demoRoot.transform);
        player.tag = "Player";
        CapsuleCollider playerCollider = player.AddComponent<CapsuleCollider>();
        playerCollider.height = 1.65f;
        playerCollider.radius = 0.36f;
        Rigidbody body = player.AddComponent<Rigidbody>();
        body.useGravity = false;
        body.isKinematic = true;
        RunnerPlayerController playerController = player.AddComponent<RunnerPlayerController>();
        controller.RegisterPlayer(playerController);
        controller.RegisterPlayerRenderer(player.GetComponent<SpriteRenderer>());

        controller.RegisterHazard(CreateInkHazard("下位地刺", spikeSprite, new Vector3(-6.1f, -2.02f, 0f), 1.05f, 0.72f, Vector3.up, demoRoot.transform));
        controller.RegisterHazard(CreateInkHazard("上方吊刃", sickleSprite, new Vector3(-3.2f, -0.35f, 0f), 1.0f, 1.35f, Vector3.down, demoRoot.transform));
        controller.RegisterHazard(CreateInkHazard("飞行暗器 A", shurikenSprite, new Vector3(-0.4f, -1.05f, 0f), 0.72f, 0.72f, Vector3.up, demoRoot.transform));
        controller.RegisterHazard(CreateInkHazard("滚石冲撞", boulderSprite, new Vector3(2.8f, -2.0f, 0f), 1.15f, 1.15f, Vector3.right, demoRoot.transform));
        controller.RegisterHazard(CreateInkHazard("影裂隙", riftSprite, new Vector3(5.9f, -0.78f, 0f), 1.35f, 0.92f, Vector3.up, demoRoot.transform));
        controller.RegisterHazard(CreateInkHazard("飞行暗器 B", shurikenSprite, new Vector3(8.0f, -1.55f, 0f), 0.72f, 0.72f, Vector3.up, demoRoot.transform));

        controller.RegisterEnemy(CreateEnemyObject("小怪 - 野猪忍兵", gruntEnemy, new Vector3(2.1f, -1.92f, -0.1f), 1.5f, 1.05f, 13, 80, demoRoot.transform));
        controller.RegisterEnemy(CreateEnemyObject("小怪 - 上位忍兵", gruntEnemy, new Vector3(5.0f, -0.54f, -0.1f), 1.5f, 1.05f, 13, 90, demoRoot.transform));
        controller.RegisterEnemy(CreateEnemyObject("精英 - 蓝武士", eliteEnemy, new Vector3(7.8f, -1.92f, -0.1f), 1.8f, 1.4f, 13, 150, demoRoot.transform));
        controller.RegisterEnemy(CreateEnemyObject("Boss - 影鬼首领", bossEnemy, new Vector3(8.6f, -1.78f, -0.1f), 2.8f, 2.0f, 13, 320, demoRoot.transform));

        GameObject weaponDoor = CreateSpriteDoor("左侧分支门 - 武器", weaponDoorSprite, new Vector3(10.65f, -1.48f, 0f), demoRoot.transform);
        weaponDoor.AddComponent<RogueDoorTrigger>().Configure(controller, RogueRewardType.Weapon);
        controller.RegisterWeaponDoor(weaponDoor.transform);
        CreateLabel("武器门\n按 E 进入", new Vector3(10.65f, 0.98f, -0.2f), 0.078f, new Color(0.24f, 0.08f, 0.02f), demoRoot.transform);

        GameObject altar = CreateSpriteObject("中央祭坛 - 关底结算", altarSprite, new Vector3(13.45f, -1.52f, -0.05f), 2.45f, 2.45f, 12, demoRoot.transform);
        controller.RegisterAltar(altar.GetComponent<SpriteRenderer>());
        CreateLabel("关底祭坛\n结算奖励", new Vector3(13.45f, 0.86f, -0.2f), 0.072f, new Color(0.14f, 0.09f, 0.02f), demoRoot.transform);

        GameObject characterDoor = CreateSpriteDoor("右侧分支门 - 角色", characterDoorSprite, new Vector3(16.25f, -1.48f, 0f), demoRoot.transform);
        characterDoor.AddComponent<RogueDoorTrigger>().Configure(controller, RogueRewardType.Character);
        controller.RegisterCharacterDoor(characterDoor.transform);
        CreateLabel("角色门\n按 E 进入", new Vector3(16.25f, 0.98f, -0.2f), 0.078f, new Color(0.03f, 0.08f, 0.24f), demoRoot.transform);

        CreateLabel("跑图终点：左武器 / 中祭坛 / 右角色", new Vector3(13.45f, 3.05f, -0.2f), 0.073f, new Color(0.06f, 0.05f, 0.04f), demoRoot.transform);
        CreateLabel("忍三局内参考：单跑道上下切位、障碍阵、小怪与 Boss、武器命中反馈", new Vector3(2.7f, 2.72f, -0.2f), 0.058f, new Color(0.12f, 0.09f, 0.06f), demoRoot.transform);

        GameObject camera = new GameObject("Main Camera");
        camera.tag = "MainCamera";
        Camera cam = camera.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.86f, 0.80f, 0.66f);
        cam.orthographic = true;
        cam.orthographicSize = 4.65f;
        camera.transform.position = new Vector3(-7.2f, 0.1f, -10f);
        camera.transform.rotation = Quaternion.identity;
        CameraFollow follow = camera.AddComponent<CameraFollow>();
        follow.SetTarget(player.transform);

        RenderSettings.ambientLight = Color.white;

        EditorSceneManager.SaveScene(scene, ScenePath);
        AddSceneToBuildSettings(ScenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"Generated {ScenePath}");
    }

    public static void CaptureDemoScreenshot()
    {
        if (!File.Exists(ScenePath))
        {
            BuildScene();
        }

        EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
        Camera camera = Camera.main;
        if (camera == null)
        {
            Debug.LogError("No main camera found for screenshot.");
            return;
        }

        const int width = 1280;
        const int height = 720;
        RenderTexture renderTexture = new RenderTexture(width, height, 24);
        Texture2D screenshot = new Texture2D(width, height, TextureFormat.RGB24, false);

        bool previousOrthographic = camera.orthographic;
        float previousSize = camera.orthographicSize;
        Vector3 previousPosition = camera.transform.position;
        Quaternion previousRotation = camera.transform.rotation;

        camera.orthographic = true;
        camera.orthographicSize = 8.7f;
        camera.transform.position = new Vector3(1.8f, 0.1f, -10f);
        camera.transform.rotation = Quaternion.identity;
        camera.targetTexture = renderTexture;
        RenderTexture.active = renderTexture;
        camera.Render();
        screenshot.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        screenshot.Apply();

        camera.targetTexture = null;
        camera.orthographic = previousOrthographic;
        camera.orthographicSize = previousSize;
        camera.transform.position = previousPosition;
        camera.transform.rotation = previousRotation;
        RenderTexture.active = null;
        Object.DestroyImmediate(renderTexture);

        string outputDir = Path.Combine(Directory.GetParent(Application.dataPath).FullName, "Outputs");
        Directory.CreateDirectory(outputDir);
        string outputPath = Path.Combine(outputDir, "NinjaRogue_DemoScreenshot.png");
        File.WriteAllBytes(outputPath, screenshot.EncodeToPNG());
        Object.DestroyImmediate(screenshot);
        Debug.Log($"Captured {outputPath}");
    }

    public static void ValidateDemoContent()
    {
        NinjaRogueCatalog catalog = NinjaRogueCatalog.LoadDefault();
        if (catalog.characters == null || catalog.characters.Length < 5)
        {
            throw new System.Exception("角色差分不足：至少需要 5 个角色。");
        }

        if (catalog.weapons == null || catalog.weapons.Length < 6)
        {
            throw new System.Exception("武器差分不足：至少需要 6 把武器。");
        }

        int expectedRooms = catalog.chapterCount * catalog.roomsPerChapter;
        if (catalog.rooms == null || catalog.rooms.Length < expectedRooms)
        {
            throw new System.Exception($"关卡差分不足：需要至少 {expectedRooms} 个房间。");
        }

        foreach (CharacterConfig character in catalog.characters)
        {
            if (Resources.Load<Sprite>($"ArtPlaceholders/Characters/{character.id}") == null)
            {
                throw new System.Exception($"缺少角色图标：{character.id}");
            }
        }

        foreach (WeaponConfig weapon in catalog.weapons)
        {
            if (Resources.Load<Sprite>($"ArtPlaceholders/Weapons/{weapon.id}") == null)
            {
                throw new System.Exception($"缺少武器图标：{weapon.id}");
            }
        }

        string[] enemyIds = { "grunt_pig", "elite_samurai", "boss_shadow" };
        foreach (string enemyId in enemyIds)
        {
            if (Resources.Load<Sprite>($"ArtPlaceholders/Enemies/{enemyId}") == null)
            {
                throw new System.Exception($"缺少怪物/Boss 资源：{enemyId}");
            }
        }

        string[] hazardPaths =
        {
            $"{InkRoot}/hazard_ground_spike.png",
            $"{InkRoot}/hazard_hanging_sickle.png",
            $"{InkRoot}/hazard_flying_shuriken.png",
            $"{InkRoot}/hazard_rolling_boulder.png",
            $"{InkRoot}/hazard_shadow_rift.png"
        };
        foreach (string hazardPath in hazardPaths)
        {
            if (AssetDatabase.LoadAssetAtPath<Sprite>(hazardPath) == null)
            {
                throw new System.Exception($"缺少忍三式障碍资源：{hazardPath}");
            }
        }

        if (!File.Exists(ScenePath))
        {
            throw new System.Exception("缺少 demo 场景。");
        }

        string screenshot = Path.Combine(Directory.GetParent(Application.dataPath).FullName, "Outputs", "NinjaRogue_DemoScreenshot.png");
        if (!File.Exists(screenshot))
        {
            throw new System.Exception("缺少 demo 截图。");
        }

        Debug.Log("Demo content validation passed: 中文配置、角色差分、武器差分、关卡差分和截图均存在。");
    }

    private static void EnsureFolders()
    {
        Directory.CreateDirectory("Assets/Scenes");
        Directory.CreateDirectory(InkRoot);
        Directory.CreateDirectory(CharacterRoot);
        Directory.CreateDirectory(WeaponRoot);
        Directory.CreateDirectory(EnemyRoot);
        Directory.CreateDirectory(ExternalRoot);
    }

    private static void GenerateVisualResources()
    {
        CreateSolidSprite($"{InkRoot}/ink_paper_sky.png", 32, 32, new Color(0.86f, 0.80f, 0.66f, 1f));
        CreateBrushSprite($"{InkRoot}/ink_mist.png", 1024, 256, new Color(1f, 1f, 1f, 0.42f), 1207);
        CreateMountainSprite($"{InkRoot}/ink_far_mountains.png", 1024, 320, new Color(0.13f, 0.15f, 0.16f, 0.42f), 1801);
        CreateMountainSprite($"{InkRoot}/ink_near_mountains.png", 1024, 320, new Color(0.04f, 0.045f, 0.05f, 0.72f), 2049);
        CreateBrushSprite($"{InkRoot}/ink_ground_stroke.png", 1024, 180, new Color(0.02f, 0.025f, 0.025f, 0.95f), 3107);
        CreateBrushSprite($"{InkRoot}/ink_bamboo_stroke.png", 128, 512, new Color(0.02f, 0.025f, 0.02f, 0.72f), 4111);
        CreateDoorSprite($"{InkRoot}/ink_weapon_gate.png", new Color(0.94f, 0.32f, 0.11f, 0.95f), 5101);
        CreateDoorSprite($"{InkRoot}/ink_character_gate.png", new Color(0.10f, 0.45f, 0.92f, 0.95f), 5209);
        CreateBladeSprite($"{InkRoot}/ink_hazard_blade.png");
        CreateSpikeSprite($"{InkRoot}/hazard_ground_spike.png");
        CreateSickleSprite($"{InkRoot}/hazard_hanging_sickle.png");
        CreateBladeSprite($"{InkRoot}/hazard_flying_shuriken.png");
        CreateBoulderSprite($"{InkRoot}/hazard_rolling_boulder.png");
        CreateRiftSprite($"{InkRoot}/hazard_shadow_rift.png");
        CreateMoonSprite($"{InkRoot}/ink_moon.png");
        CreateAltarSprite($"{InkRoot}/ink_reward_altar.png");

        CreateCharacterSprite($"{CharacterRoot}/flame_runner.png", new Color(1f, 0.20f, 0.06f, 0.95f), $"{ExternalRoot}/ninja_blue_sheet.png", 0);
        CreateCharacterSprite($"{CharacterRoot}/storm_runner.png", new Color(1f, 0.86f, 0.08f, 0.95f), $"{ExternalRoot}/samurai_blue_sheet.png", 1);
        CreateCharacterSprite($"{CharacterRoot}/frost_runner.png", new Color(0.32f, 0.82f, 1f, 0.95f), $"{ExternalRoot}/ninja_blue_sheet.png", 2);
        CreateCharacterSprite($"{CharacterRoot}/wind_runner.png", new Color(0.38f, 1f, 0.55f, 0.95f), $"{ExternalRoot}/samurai_green_sheet.png", 0);
        CreateCharacterSprite($"{CharacterRoot}/shadow_runner.png", new Color(0.62f, 0.24f, 1f, 0.95f), $"{ExternalRoot}/samurai_blue_sheet.png", 2);

        CreateWeaponSprite($"{WeaponRoot}/fire_wheel.png", "fire_wheel", new Color(1f, 0.28f, 0.04f, 0.98f), $"{ExternalRoot}/weapon_axe.png");
        CreateWeaponSprite($"{WeaponRoot}/thunder_blade.png", "thunder_blade", new Color(1f, 0.88f, 0.08f, 0.98f), $"{ExternalRoot}/weapon_big_sword.png");
        CreateWeaponSprite($"{WeaponRoot}/ice_orb.png", "ice_orb", new Color(0.26f, 0.78f, 1f, 0.98f), $"{ExternalRoot}/weapon_club.png");
        CreateWeaponSprite($"{WeaponRoot}/wind_scythe.png", "wind_scythe", new Color(0.36f, 1f, 0.48f, 0.98f), $"{ExternalRoot}/weapon_axe.png");
        CreateWeaponSprite($"{WeaponRoot}/shadow_kunai.png", "shadow_kunai", new Color(0.58f, 0.22f, 1f, 0.98f), $"{ExternalRoot}/weapon_big_sword.png");
        CreateWeaponSprite($"{WeaponRoot}/jade_brush.png", "jade_brush", new Color(0.95f, 0.82f, 0.42f, 0.98f), $"{ExternalRoot}/weapon_club.png");

        CreateEnemySprite($"{EnemyRoot}/grunt_pig.png", $"{ExternalRoot}/pig.png", new Color(0.88f, 0.32f, 0.18f, 0.96f), 4);
        CreateEnemySprite($"{EnemyRoot}/elite_samurai.png", $"{ExternalRoot}/samurai_blue_sheet.png", new Color(0.35f, 0.55f, 1f, 0.96f), 5);
        CreateEnemySprite($"{EnemyRoot}/boss_shadow.png", $"{ExternalRoot}/shadow.png", new Color(0.62f, 0.18f, 0.95f, 0.96f), 10);

        AssetDatabase.Refresh();
    }

    private static Sprite LoadSprite(string path)
    {
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    private static GameObject CreateSpriteObject(string name, Sprite sprite, Vector3 position, float width, float height, int sortingOrder, Transform parent)
    {
        GameObject obj = new GameObject(name);
        obj.transform.position = position;
        obj.transform.SetParent(parent);
        SpriteRenderer renderer = obj.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = sortingOrder;
        Vector2 size = sprite.bounds.size;
        obj.transform.localScale = new Vector3(width / size.x, height / size.y, 1f);
        return obj;
    }

    private static GameObject CreateSpriteDoor(string name, Sprite sprite, Vector3 position, Transform parent)
    {
        GameObject door = CreateSpriteObject(name, sprite, position, 2.15f, 3.35f, 3, parent);
        BoxCollider collider = door.AddComponent<BoxCollider>();
        collider.isTrigger = true;
        collider.size = new Vector3(0.9f, 1.0f, 1f);
        return door;
    }

    private static AutoHazard CreateInkHazard(string name, Sprite sprite, Vector3 position, float width, float height, Vector3 axis, Transform parent)
    {
        GameObject hazard = CreateSpriteObject(name, sprite, position, width, height, 9, parent);
        AutoHazard autoHazard = hazard.AddComponent<AutoHazard>();
        SerializedObject serialized = new SerializedObject(autoHazard);
        serialized.FindProperty("axis").vector3Value = axis;
        serialized.ApplyModifiedPropertiesWithoutUndo();
        return autoHazard;
    }

    private static DemoEnemy CreateEnemyObject(string name, Sprite sprite, Vector3 position, float width, float height, int sortingOrder, int hp, Transform parent)
    {
        GameObject enemy = CreateSpriteObject(name, sprite, position, width, height, sortingOrder, parent);
        BoxCollider collider = enemy.AddComponent<BoxCollider>();
        collider.isTrigger = true;
        collider.size = new Vector3(0.85f, 0.85f, 1f);
        DemoEnemy demoEnemy = enemy.AddComponent<DemoEnemy>();
        demoEnemy.Configure(name.Replace("小怪 - ", "").Replace("精英 - ", "").Replace("Boss - ", ""), hp);
        return demoEnemy;
    }

    private static Transform CreateMarker(string name, Vector3 position, Transform parent)
    {
        GameObject marker = new GameObject(name);
        marker.transform.position = position;
        marker.transform.SetParent(parent);
        return marker.transform;
    }

    private static void CreateLabel(string text, Vector3 position, float size, Color color, Transform parent)
    {
        GameObject label = new GameObject("Label - " + text.Split('\n')[0]);
        label.transform.position = position;
        label.transform.SetParent(parent);
        TextMesh mesh = label.AddComponent<TextMesh>();
        mesh.text = text;
        mesh.anchor = TextAnchor.MiddleCenter;
        mesh.alignment = TextAlignment.Center;
        mesh.characterSize = size;
        mesh.fontSize = 48;
        mesh.color = color;

        Font font = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "SimHei", "Arial Unicode MS", "Arial" }, 48);
        if (font != null)
        {
            mesh.font = font;
            MeshRenderer renderer = label.GetComponent<MeshRenderer>();
            renderer.sharedMaterial = font.material;
        }
    }

    private static Sprite CreateSolidSprite(string path, int width, int height, Color color)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                float noise = Mathf.PerlinNoise(x * 0.23f, y * 0.23f) * 0.045f;
                texture.SetPixel(x, y, new Color(color.r + noise, color.g + noise, color.b + noise, color.a));
            }
        }

        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateBrushSprite(string path, int width, int height, Color color, int seed)
    {
        Texture2D texture = CreateTransparentTexture(width, height);
        System.Random random = new System.Random(seed);
        for (int i = 0; i < 170; i++)
        {
            int cx = random.Next(0, width);
            int cy = random.Next(height / 4, height * 3 / 4);
            int rx = random.Next(width / 28, width / 9);
            int ry = random.Next(height / 14, height / 4);
            FillEllipse(texture, cx, cy, rx, ry, color);
        }

        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateMountainSprite(string path, int width, int height, Color color, int seed)
    {
        Texture2D texture = CreateTransparentTexture(width, height);
        System.Random random = new System.Random(seed);
        int[] ridge = new int[width];
        int current = height / 2;
        for (int x = 0; x < width; x++)
        {
            current += random.Next(-3, 4);
            current = Mathf.Clamp(current, height / 4, height * 3 / 4);
            ridge[x] = current;
        }

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < ridge[x]; y++)
            {
                float alpha = color.a * Mathf.Lerp(1f, 0.2f, y / (float)height);
                texture.SetPixel(x, y, new Color(color.r, color.g, color.b, alpha));
            }
        }

        for (int i = 0; i < 90; i++)
        {
            int cx = random.Next(0, width);
            int cy = random.Next(0, height / 2);
            FillEllipse(texture, cx, cy, random.Next(14, 44), random.Next(6, 18), new Color(color.r, color.g, color.b, color.a * 0.35f));
        }

        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateDoorSprite(string path, Color color, int seed)
    {
        Texture2D texture = CreateTransparentTexture(256, 512);
        System.Random random = new System.Random(seed);
        for (int i = 0; i < 65; i++)
        {
            int cx = random.Next(84, 172);
            int cy = random.Next(48, 470);
            int rx = random.Next(10, 32);
            int ry = random.Next(18, 56);
            FillEllipse(texture, cx, cy, rx, ry, color);
        }

        for (int i = 0; i < 18; i++)
        {
            FillRect(texture, random.Next(78, 154), random.Next(60, 420), random.Next(10, 22), random.Next(42, 90), color);
        }

        FillEllipse(texture, 128, 270, 55, 120, new Color(color.r, color.g, color.b, color.a * 0.38f));
        FillEllipse(texture, 128, 270, 30, 88, new Color(0.98f, 0.92f, 0.76f, 0.72f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateBladeSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(180, 180);
        Color red = new Color(0.73f, 0.05f, 0.05f, 0.88f);
        FillEllipse(texture, 90, 90, 58, 14, red);
        FillEllipse(texture, 90, 90, 14, 58, red);
        FillEllipse(texture, 90, 90, 20, 20, new Color(0.05f, 0.02f, 0.02f, 0.88f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateSpikeSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(220, 128);
        Color ink = new Color(0.03f, 0.025f, 0.02f, 0.96f);
        Color red = new Color(0.78f, 0.04f, 0.03f, 0.9f);
        for (int i = 0; i < 6; i++)
        {
            int cx = 22 + i * 34;
            FillTriangle(texture, cx - 16, 24, cx + 16, 24, cx, 104, ink);
            FillTriangle(texture, cx - 7, 28, cx + 7, 28, cx, 78, red);
        }

        FillEllipse(texture, 110, 20, 98, 11, new Color(ink.r, ink.g, ink.b, 0.74f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateSickleSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(180, 240);
        Color ink = new Color(0.03f, 0.025f, 0.02f, 0.94f);
        Color red = new Color(0.75f, 0.03f, 0.02f, 0.9f);
        FillRect(texture, 86, 138, 8, 90, ink);
        FillEllipse(texture, 90, 114, 64, 18, ink);
        FillEllipse(texture, 98, 116, 40, 10, red);
        FillEllipse(texture, 52, 112, 14, 30, red);
        FillEllipse(texture, 128, 112, 14, 30, red);
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateBoulderSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(180, 180);
        Color ink = new Color(0.035f, 0.035f, 0.032f, 0.96f);
        Color gray = new Color(0.18f, 0.17f, 0.14f, 0.86f);
        FillEllipse(texture, 90, 82, 58, 52, ink);
        FillEllipse(texture, 78, 96, 24, 18, gray);
        FillEllipse(texture, 106, 67, 20, 16, gray);
        FillEllipse(texture, 102, 102, 14, 12, new Color(0.64f, 0.04f, 0.03f, 0.8f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateRiftSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(220, 160);
        Color dark = new Color(0.02f, 0.015f, 0.03f, 0.92f);
        Color purple = new Color(0.55f, 0.12f, 0.92f, 0.86f);
        FillEllipse(texture, 110, 78, 84, 26, dark);
        FillEllipse(texture, 110, 78, 56, 14, purple);
        for (int i = 0; i < 7; i++)
        {
            FillEllipse(texture, 48 + i * 20, 78 + (i % 2 == 0 ? 18 : -18), 8, 28, purple);
        }

        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateMoonSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(256, 256);
        FillEllipse(texture, 128, 128, 78, 78, new Color(0.98f, 0.93f, 0.78f, 0.68f));
        FillEllipse(texture, 152, 146, 68, 68, new Color(0.86f, 0.80f, 0.66f, 0.82f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateAltarSprite(string path)
    {
        Texture2D texture = CreateTransparentTexture(256, 256);
        Color ink = new Color(0.03f, 0.025f, 0.02f, 0.95f);
        Color gold = new Color(0.95f, 0.80f, 0.38f, 0.85f);
        FillEllipse(texture, 128, 58, 92, 24, ink);
        FillRect(texture, 72, 58, 112, 38, ink);
        FillEllipse(texture, 128, 122, 64, 52, new Color(ink.r, ink.g, ink.b, 0.78f));
        FillEllipse(texture, 128, 142, 36, 42, gold);
        FillEllipse(texture, 128, 142, 18, 22, new Color(1f, 0.95f, 0.72f, 0.72f));
        FillEllipse(texture, 88, 110, 20, 8, gold);
        FillEllipse(texture, 168, 110, 20, 8, gold);
        return SaveSprite(path, texture, true, 100f, FilterMode.Bilinear);
    }

    private static Sprite CreateEnemySprite(string path, string sourcePath, Color accent, int scale)
    {
        Texture2D texture = CreateTransparentTexture(192, 160);
        Color shadow = new Color(0.02f, 0.018f, 0.015f, 0.72f);
        FillEllipse(texture, 96, 28, 64, 16, shadow);
        if (sourcePath.EndsWith("samurai_blue_sheet.png"))
        {
            StampPngFrame(texture, sourcePath, 0, 16, 50, 44, scale, accent);
        }
        else
        {
            StampWholePng(texture, sourcePath, 52, 42, scale, accent);
        }

        FillEllipse(texture, 96, 104, 74, 34, new Color(accent.r, accent.g, accent.b, 0.22f));
        FillEllipse(texture, 126, 86, 20, 8, new Color(1f, 0.18f, 0.08f, 0.82f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Point);
    }

    private static Sprite CreateCharacterSprite(string path, Color accent, string sourceSheet, int frameColumn)
    {
        Texture2D texture = CreateTransparentTexture(160, 192);
        Color ink = new Color(0.025f, 0.025f, 0.025f, 0.98f);
        FillEllipse(texture, 80, 104, 52, 62, new Color(accent.r, accent.g, accent.b, 0.16f));
        FillEllipse(texture, 62, 35, 52, 10, new Color(accent.r, accent.g, accent.b, 0.42f));
        StampPngFrame(texture, sourceSheet, frameColumn, 16, 34, 54, 5, new Color(accent.r, accent.g, accent.b, 0.92f));
        FillEllipse(texture, 82, 48, 42, 10, ink);
        FillRect(texture, 88, 126, 58, 10, accent);
        FillEllipse(texture, 132, 130, 34, 8, accent);
        FillEllipse(texture, 58, 136, 12, 5, new Color(1f, 1f, 1f, 0.82f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Point);
    }

    private static Sprite CreateWeaponSprite(string path, string id, Color accent, string sourceIcon)
    {
        Texture2D texture = CreateTransparentTexture(96, 96);
        Color ink = new Color(0.04f, 0.035f, 0.03f, 0.88f);
        FillEllipse(texture, 48, 48, 42, 42, new Color(0.94f, 0.84f, 0.58f, 0.55f));
        FillEllipse(texture, 48, 48, 36, 36, new Color(ink.r, ink.g, ink.b, 0.24f));

        if (id == "fire_wheel")
        {
            FillEllipse(texture, 48, 48, 27, 27, accent);
            FillEllipse(texture, 48, 48, 15, 15, new Color(0.98f, 0.85f, 0.46f, 0.82f));
        }
        else if (id == "thunder_blade")
        {
            FillRect(texture, 42, 14, 12, 66, accent);
            FillEllipse(texture, 54, 70, 22, 10, accent);
        }
        else if (id == "ice_orb")
        {
            FillEllipse(texture, 48, 48, 30, 30, accent);
            FillEllipse(texture, 38, 58, 10, 10, new Color(1f, 1f, 1f, 0.72f));
        }
        else if (id == "wind_scythe")
        {
            FillEllipse(texture, 42, 54, 32, 8, accent);
            FillEllipse(texture, 56, 42, 32, 8, accent);
        }
        else if (id == "shadow_kunai")
        {
            FillEllipse(texture, 48, 48, 10, 34, accent);
            FillEllipse(texture, 48, 22, 22, 8, accent);
        }
        else
        {
            FillRect(texture, 43, 20, 10, 50, accent);
            FillEllipse(texture, 48, 73, 20, 10, accent);
        }

        StampWholePng(texture, sourceIcon, 34, 30, 4, new Color(accent.r, accent.g, accent.b, 0.92f));
        return SaveSprite(path, texture, true, 100f, FilterMode.Point);
    }

    private static Texture2D CreateTransparentTexture(int width, int height)
    {
        Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
        Color clear = new Color(0f, 0f, 0f, 0f);
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                texture.SetPixel(x, y, clear);
            }
        }

        return texture;
    }

    private static Sprite SaveSprite(string path, Texture2D texture, bool alpha, float pixelsPerUnit, FilterMode filterMode)
    {
        File.WriteAllBytes(path, texture.EncodeToPNG());
        Object.DestroyImmediate(texture);
        AssetDatabase.ImportAsset(path);
        TextureImporter importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType = TextureImporterType.Sprite;
        importer.spritePixelsPerUnit = pixelsPerUnit;
        importer.alphaIsTransparency = alpha;
        importer.mipmapEnabled = false;
        importer.filterMode = filterMode;
        importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    private static void StampPngFrame(Texture2D target, string sourcePath, int column, int frameWidth, int dstX, int dstY, int scale, Color tint)
    {
        if (!File.Exists(sourcePath))
        {
            return;
        }

        Texture2D source = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        source.LoadImage(File.ReadAllBytes(sourcePath));
        int sx0 = Mathf.Clamp(column * frameWidth, 0, Mathf.Max(0, source.width - frameWidth));
        int sy0 = Mathf.Max(0, source.height - frameWidth);
        for (int y = 0; y < frameWidth; y++)
        {
            for (int x = 0; x < frameWidth; x++)
            {
                Color sourceColor = source.GetPixel(sx0 + x, sy0 + y);
                if (sourceColor.a < 0.08f)
                {
                    continue;
                }

                float gray = sourceColor.grayscale;
                Color stamped = Color.Lerp(new Color(gray, gray, gray, sourceColor.a), tint, 0.58f);
                stamped.a = sourceColor.a * tint.a;
                FillRect(target, dstX + x * scale, dstY + y * scale, scale, scale, stamped);
            }
        }

        Object.DestroyImmediate(source);
    }

    private static void StampWholePng(Texture2D target, string sourcePath, int dstX, int dstY, int scale, Color tint)
    {
        if (!File.Exists(sourcePath))
        {
            return;
        }

        Texture2D source = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        source.LoadImage(File.ReadAllBytes(sourcePath));
        for (int y = 0; y < source.height; y++)
        {
            for (int x = 0; x < source.width; x++)
            {
                Color sourceColor = source.GetPixel(x, y);
                if (sourceColor.a < 0.08f)
                {
                    continue;
                }

                float gray = sourceColor.grayscale;
                Color stamped = Color.Lerp(new Color(gray, gray, gray, sourceColor.a), tint, 0.55f);
                stamped.a = sourceColor.a * tint.a;
                FillRect(target, dstX + x * scale, dstY + y * scale, scale, scale, stamped);
            }
        }

        Object.DestroyImmediate(source);
    }

    private static void FillEllipse(Texture2D texture, int cx, int cy, int rx, int ry, Color color)
    {
        for (int y = Mathf.Max(0, cy - ry); y < Mathf.Min(texture.height, cy + ry); y++)
        {
            for (int x = Mathf.Max(0, cx - rx); x < Mathf.Min(texture.width, cx + rx); x++)
            {
                float dx = (x - cx) / (float)rx;
                float dy = (y - cy) / (float)ry;
                if (dx * dx + dy * dy <= 1f)
                {
                    Color existing = texture.GetPixel(x, y);
                    texture.SetPixel(x, y, AlphaBlend(existing, color));
                }
            }
        }
    }

    private static void FillRect(Texture2D texture, int x, int y, int width, int height, Color color)
    {
        for (int py = Mathf.Max(0, y); py < Mathf.Min(texture.height, y + height); py++)
        {
            for (int px = Mathf.Max(0, x); px < Mathf.Min(texture.width, x + width); px++)
            {
                Color existing = texture.GetPixel(px, py);
                texture.SetPixel(px, py, AlphaBlend(existing, color));
            }
        }
    }

    private static void FillTriangle(Texture2D texture, int x1, int y1, int x2, int y2, int x3, int y3, Color color)
    {
        int minX = Mathf.Max(0, Mathf.Min(x1, Mathf.Min(x2, x3)));
        int maxX = Mathf.Min(texture.width - 1, Mathf.Max(x1, Mathf.Max(x2, x3)));
        int minY = Mathf.Max(0, Mathf.Min(y1, Mathf.Min(y2, y3)));
        int maxY = Mathf.Min(texture.height - 1, Mathf.Max(y1, Mathf.Max(y2, y3)));

        float area = Edge(x1, y1, x2, y2, x3, y3);
        if (Mathf.Abs(area) < 0.001f)
        {
            return;
        }

        for (int y = minY; y <= maxY; y++)
        {
            for (int x = minX; x <= maxX; x++)
            {
                float w0 = Edge(x2, y2, x3, y3, x, y);
                float w1 = Edge(x3, y3, x1, y1, x, y);
                float w2 = Edge(x1, y1, x2, y2, x, y);
                bool inside = area > 0f ? w0 >= 0f && w1 >= 0f && w2 >= 0f : w0 <= 0f && w1 <= 0f && w2 <= 0f;
                if (inside)
                {
                    Color existing = texture.GetPixel(x, y);
                    texture.SetPixel(x, y, AlphaBlend(existing, color));
                }
            }
        }
    }

    private static float Edge(int ax, int ay, int bx, int by, int px, int py)
    {
        return (px - ax) * (by - ay) - (py - ay) * (bx - ax);
    }

    private static Color AlphaBlend(Color baseColor, Color overlay)
    {
        float alpha = overlay.a + baseColor.a * (1f - overlay.a);
        if (alpha <= 0f)
        {
            return Color.clear;
        }

        return new Color(
            (overlay.r * overlay.a + baseColor.r * baseColor.a * (1f - overlay.a)) / alpha,
            (overlay.g * overlay.a + baseColor.g * baseColor.a * (1f - overlay.a)) / alpha,
            (overlay.b * overlay.a + baseColor.b * baseColor.a * (1f - overlay.a)) / alpha,
            alpha);
    }

    private static void AddSceneToBuildSettings(string scenePath)
    {
        EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
        foreach (EditorBuildSettingsScene item in scenes)
        {
            if (item.path == scenePath)
            {
                item.enabled = true;
                return;
            }
        }

        EditorBuildSettingsScene[] updated = new EditorBuildSettingsScene[scenes.Length + 1];
        scenes.CopyTo(updated, 0);
        updated[updated.Length - 1] = new EditorBuildSettingsScene(scenePath, true);
        EditorBuildSettings.scenes = updated;
    }
}
