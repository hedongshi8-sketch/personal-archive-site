using UnityEngine;

public sealed class WeaponPreviewEffect : MonoBehaviour
{
    private Vector3 velocity;
    private float lifetime = 1f;
    private float age;
    private float spin;
    private float pulse;
    private int damage = 24;
    private string weaponName = "武器";
    private SpriteRenderer spriteRenderer;
    private Color startColor = Color.white;
    private Vector3 startScale;

    public void Initialize(Vector3 moveVelocity, float duration, float spinSpeed, float pulseAmount, Color color, int weaponDamage = 24, string displayName = "武器")
    {
        velocity = moveVelocity;
        lifetime = Mathf.Max(0.1f, duration);
        spin = spinSpeed;
        pulse = pulseAmount;
        damage = Mathf.Max(1, weaponDamage);
        weaponName = displayName;
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
        {
            spriteRenderer.color = color;
            startColor = color;
        }

        startScale = transform.localScale;
    }

    private void OnTriggerEnter(Collider other)
    {
        DemoEnemy enemy = other.GetComponent<DemoEnemy>();
        if (enemy != null)
        {
            enemy.TakeHit(damage, weaponName);
        }
    }

    private void Update()
    {
        age += Time.deltaTime;
        transform.position += velocity * Time.deltaTime;
        transform.Rotate(Vector3.forward, spin * Time.deltaTime);

        float t = Mathf.Clamp01(age / lifetime);
        float scale = 1f + Mathf.Sin(t * Mathf.PI) * pulse;
        transform.localScale = startScale * scale;

        if (spriteRenderer != null)
        {
            Color color = startColor;
            color.a *= 1f - t;
            spriteRenderer.color = color;
        }

        if (age >= lifetime)
        {
            Destroy(gameObject);
        }
    }
}
