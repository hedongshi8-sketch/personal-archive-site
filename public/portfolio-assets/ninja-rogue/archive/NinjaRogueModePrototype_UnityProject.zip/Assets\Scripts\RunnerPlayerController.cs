using UnityEngine;

public sealed class RunnerPlayerController : MonoBehaviour
{
    [SerializeField] private float runMinX = -14f;
    [SerializeField] private float runMaxX = 18f;
    [SerializeField] private float lowerLaneY = -2.15f;
    [SerializeField] private float upperLaneY = -0.72f;
    [SerializeField] private float ceilingOffset = 2.1f;
    [SerializeField] private float jumpVelocity = 8.2f;
    [SerializeField] private float gravity = 24f;
    [SerializeField] private float dashDistance = 3.2f;
    [SerializeField] private float dashCooldown = 1.1f;
    [SerializeField] private float laneSwitchSpeed = 18f;

    private float dashTimer;
    private float verticalVelocity;
    private int laneIndex;
    private float jumpOffset;

    public bool InputEnabled { get; set; } = true;
    public float MoveSpeed { get; set; } = 8f;
    public float JumpVelocity { get => jumpVelocity; set => jumpVelocity = value; }
    public float DashDistance { get => dashDistance; set => dashDistance = value; }
    public float DashCooldown { get => dashCooldown; set => dashCooldown = value; }
    public float DashCooldownRemaining => Mathf.Max(0f, dashTimer);
    public int CurrentLane => laneIndex;
    public float CurrentLaneY => laneIndex == 0 ? lowerLaneY : upperLaneY;

    public void ConfigureMovement(float speed, float jump, float dash, float cooldown)
    {
        MoveSpeed = speed;
        JumpVelocity = jump;
        DashDistance = dash;
        DashCooldown = cooldown;
    }

    public void ResetToLowerLane()
    {
        laneIndex = 0;
        jumpOffset = 0f;
        verticalVelocity = 0f;
    }

    private void Update()
    {
        dashTimer -= Time.deltaTime;
        if (!InputEnabled)
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            laneIndex = 1;
        }
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
        {
            laneIndex = 0;
        }

        float horizontal = Input.GetAxisRaw("Horizontal");
        transform.position += new Vector3(horizontal * MoveSpeed * Time.deltaTime, 0f, 0f);

        bool groundedOnLane = jumpOffset <= 0.01f;
        if (Input.GetKeyDown(KeyCode.Space) && groundedOnLane)
        {
            verticalVelocity = jumpVelocity;
        }

        verticalVelocity -= gravity * Time.deltaTime;
        jumpOffset += verticalVelocity * Time.deltaTime;
        if (jumpOffset <= 0f)
        {
            jumpOffset = 0f;
            if (verticalVelocity < 0f)
            {
                verticalVelocity = 0f;
            }
        }

        if ((Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)) && dashTimer <= 0f)
        {
            float direction = Mathf.Abs(horizontal) > 0.1f ? Mathf.Sign(horizontal) : 1f;
            transform.position += new Vector3(direction * dashDistance, 0f, 0f);
            dashTimer = dashCooldown;
        }

        float targetY = CurrentLaneY + Mathf.Min(jumpOffset, ceilingOffset);
        Vector3 clamped = transform.position;
        clamped.x = Mathf.Clamp(clamped.x, runMinX, runMaxX);
        clamped.y = Mathf.Lerp(clamped.y, targetY, Time.deltaTime * laneSwitchSpeed);
        clamped.z = 0f;
        transform.position = clamped;
    }
}
