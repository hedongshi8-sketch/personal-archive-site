using UnityEngine;

[RequireComponent(typeof(Collider))]
public sealed class RogueDoorTrigger : MonoBehaviour
{
    [SerializeField] private RogueRewardType rewardType = RogueRewardType.Weapon;
    [SerializeField] private NinjaRogueDemoController controller;

    public void Configure(NinjaRogueDemoController demoController, RogueRewardType type)
    {
        controller = demoController;
        rewardType = type;
    }

    private void Reset()
    {
        Collider trigger = GetComponent<Collider>();
        trigger.isTrigger = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        // Door choice is explicit so the player can pass one gate and choose the other.
    }

    private void OnTriggerStay(Collider other)
    {
        if (!other.CompareTag("Player") || !Input.GetKeyDown(KeyCode.E))
        {
            return;
        }

        if (controller == null)
        {
            controller = FindObjectOfType<NinjaRogueDemoController>();
        }

        controller?.OpenDoor(rewardType);
    }
}
