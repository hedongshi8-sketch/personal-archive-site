using UnityEngine;

public sealed class WorldLabel : MonoBehaviour
{
    private Camera targetCamera;

    private void Start()
    {
        targetCamera = Camera.main;
    }

    private void LateUpdate()
    {
        if (targetCamera == null)
        {
            return;
        }

        transform.rotation = Quaternion.LookRotation(transform.position - targetCamera.transform.position);
    }
}
