using UnityEngine;

public sealed class AutoHazard : MonoBehaviour
{
    [SerializeField] private float amplitude = 1.8f;
    [SerializeField] private float speed = 1.4f;
    [SerializeField] private Vector3 axis = Vector3.forward;

    private Vector3 startPosition;

    private void Start()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        transform.position = startPosition + axis.normalized * Mathf.Sin(Time.time * speed) * amplitude;
    }
}
