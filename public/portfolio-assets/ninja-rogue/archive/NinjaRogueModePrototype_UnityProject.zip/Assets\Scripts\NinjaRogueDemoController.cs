using System.Collections.Generic;
using UnityEngine;

public sealed class NinjaRogueDemoController : MonoBehaviour
{
    [SerializeField] private RunnerPlayerController player;
    [SerializeField] private SpriteRenderer playerRenderer;
    [SerializeField] private Transform playerStart;
    [SerializeField] private Transform weaponDoor;
    [SerializeField] private Transform characterDoor;
    [SerializeField] private SpriteRenderer altarRenderer;
    [SerializeField] private SpriteRenderer atmosphereRenderer;

    private readonly RogueRunState runState = new RogueRunState();
    private readonly List<AutoHazard> hazards = new List<AutoHazard>();
    private readonly List<DemoEnemy> enemies = new List<DemoEnemy>();
    private readonly Dictionary<string, Texture2D> textureCache = new Dictionary<string, Texture2D>();
    private NinjaRogueCatalog catalog;
    private List<RewardOption> currentOffer = new List<RewardOption>();
    private RogueRewardType currentOfferType;
    private bool showingOffer;
    private float weaponCooldownTimer;
    private GUIStyle titleStyle;
    private GUIStyle bodyStyle;
    private GUIStyle tinyStyle;
    private GUIStyle cardTitleTextStyle;
    private GUIStyle cardBodyTextStyle;
    private GUIStyle cardTinyTextStyle;
    private GUIStyle panelStyle;
    private GUIStyle cardStyle;
    private GUIStyle badgeStyle;
    private Font chineseFont;
    private Texture2D panelTexture;
    private Texture2D cardTexture;

    public void RegisterPlayer(RunnerPlayerController value)
    {
        player = value;
    }

    public void RegisterPlayerRenderer(SpriteRenderer value)
    {
        playerRenderer = value;
    }

    public void RegisterPlayerStart(Transform value)
    {
        playerStart = value;
    }

    public void RegisterWeaponDoor(Transform value)
    {
        weaponDoor = value;
    }

    public void RegisterCharacterDoor(Transform value)
    {
        characterDoor = value;
    }

    public void RegisterAltar(SpriteRenderer value)
    {
        altarRenderer = value;
    }

    public void RegisterAtmosphere(SpriteRenderer value)
    {
        atmosphereRenderer = value;
    }

    public void RegisterHazard(AutoHazard value)
    {
        if (value != null && !hazards.Contains(value))
        {
            hazards.Add(value);
        }
    }

    public void RegisterEnemy(DemoEnemy value)
    {
        if (value != null && !enemies.Contains(value))
        {
            enemies.Add(value);
        }
    }

    private void Start()
    {
        catalog = NinjaRogueCatalog.LoadDefault();
        int seed = System.DateTime.Now.Millisecond + System.DateTime.Now.Second * 1000;
        runState.Start(catalog, seed);
        ApplyCurrentCharacterStats();
        ResetRoom();
    }

    private void Update()
    {
        if (catalog == null)
        {
            return;
        }

        weaponCooldownTimer = Mathf.Max(0f, weaponCooldownTimer - Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.Tab) && !showingOffer)
        {
            runState.SwapCharacter();
            ApplyCurrentCharacterStats();
        }

        if (Input.GetKeyDown(KeyCode.J) && !showingOffer)
        {
            CastCurrentWeapon();
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            runState.Start(catalog, runState.Seed + 17);
            showingOffer = false;
            weaponCooldownTimer = 0f;
            ApplyCurrentCharacterStats();
            ResetRoom();
        }

        if (!showingOffer)
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            SelectOffer(0);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            SelectOffer(1);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            SelectOffer(2);
        }
        else if (Input.GetKeyDown(KeyCode.Escape))
        {
            SelectOffer(-1);
        }
    }

    public void OpenDoor(RogueRewardType rewardType)
    {
        if (showingOffer || catalog == null)
        {
            return;
        }

        currentOfferType = rewardType;
        currentOffer = runState.GenerateOffer(catalog, rewardType);
        showingOffer = true;
        if (player != null)
        {
            player.InputEnabled = false;
        }

        HighlightAltar(rewardType);
    }

    private void SelectOffer(int index)
    {
        RewardOption option = index >= 0 && index < currentOffer.Count ? currentOffer[index] : null;
        runState.ChooseReward(catalog, option);
        showingOffer = false;
        weaponCooldownTimer = 0f;
        ApplyCurrentCharacterStats();
        ResetRoom();
    }

    private void ResetRoom()
    {
        if (player != null && playerStart != null)
        {
            player.transform.position = playerStart.position;
            player.ResetToLowerLane();
            player.InputEnabled = true;
        }

        RoomConfig room = runState.GetCurrentRoom(catalog);
        ApplyRoomVisual(room);
        HighlightAltar(null);
    }

    private void ApplyCurrentCharacterStats()
    {
        if (player == null || runState.CurrentCharacter == null)
        {
            return;
        }

        CharacterConfig character = runState.CurrentCharacter;
        float jump = 8.2f;
        float dash = 3.2f;
        float cooldown = 1.05f;

        if (character.archetype == "连击" || character.archetype == "Combo")
        {
            cooldown = 0.72f;
        }
        else if (character.archetype == "控制" || character.archetype == "Control")
        {
            jump = 7.8f;
            dash = 2.8f;
            cooldown = 1.25f;
        }
        else if (character.archetype == "机动" || character.archetype == "Mobility")
        {
            jump = 9.2f;
            dash = 4.25f;
            cooldown = 0.82f;
        }
        else if (character.archetype == "风险" || character.archetype == "Risk")
        {
            dash = 3.65f;
            cooldown = 0.92f;
        }

        player.ConfigureMovement(character.moveSpeed, jump, dash, cooldown);

        if (playerRenderer != null)
        {
            Sprite sprite = Resources.Load<Sprite>($"ArtPlaceholders/Characters/{character.id}");
            if (sprite != null)
            {
                playerRenderer.sprite = sprite;
            }

            playerRenderer.color = Color.white;
        }
    }

    private void ApplyRoomVisual(RoomConfig room)
    {
        if (room == null)
        {
            return;
        }

        int activeCount = Mathf.Clamp(2 + Mathf.RoundToInt(room.hazardDensity * hazards.Count), 1, hazards.Count);
        for (int i = 0; i < hazards.Count; i++)
        {
            AutoHazard hazard = hazards[i];
            bool active = i < activeCount;
            hazard.gameObject.SetActive(active);
            if (!active)
            {
                continue;
            }

            float spread = Mathf.Lerp(13f, 18f, Mathf.Clamp01(room.hazardDensity));
            float x = -7.5f + spread * (i + 1f) / (activeCount + 1f);
            float laneOffset = ((i + room.difficulty) % 3 - 1) * 0.48f;
            hazard.transform.position = new Vector3(x, -1.28f + laneOffset, 0f);
            float scale = Mathf.Lerp(0.65f, 1.2f, room.hazardDensity) + i * 0.03f;
            hazard.transform.localScale = new Vector3(scale, scale, 1f);

            SpriteRenderer renderer = hazard.GetComponent<SpriteRenderer>();
            if (renderer != null)
            {
                renderer.color = GetRoomHazardColor(room);
            }
        }

        if (atmosphereRenderer != null)
        {
            atmosphereRenderer.color = GetRoomTint(room);
        }

        int enemyCount = room.roomType == "Boss" ? 1 : room.roomType == "精英" || room.roomType == "Elite" ? 2 : 3;
        enemyCount = Mathf.Clamp(enemyCount, 0, enemies.Count);
        for (int i = 0; i < enemies.Count; i++)
        {
            DemoEnemy enemy = enemies[i];
            bool active = i < enemyCount;
            enemy.gameObject.SetActive(active);
            if (!active)
            {
                continue;
            }

            float laneY = (i + room.difficulty) % 2 == 0 ? -2.0f : -0.72f;
            float x = room.roomType == "Boss" && i == 0 ? 8.6f : 1.8f + i * 3.25f;
            int hp = room.roomType == "Boss" ? 260 + room.difficulty * 30 : room.roomType == "精英" || room.roomType == "Elite" ? 150 : 72 + room.difficulty * 16;
            enemy.ResetEnemy(new Vector3(x, laneY + 0.24f, -0.1f), hp);
            enemy.transform.localScale = room.roomType == "Boss" && i == 0 ? Vector3.one * 2.5f : Vector3.one * 1.45f;
        }
    }

    private void CastCurrentWeapon()
    {
        WeaponConfig weapon = runState.CurrentWeapon;
        if (weapon == null || player == null)
        {
            return;
        }

        if (weaponCooldownTimer > 0f)
        {
            return;
        }

        Sprite sprite = Resources.Load<Sprite>($"ArtPlaceholders/Weapons/{weapon.id}");
        if (sprite == null)
        {
            return;
        }

        GameObject obj = new GameObject("武器试放 - " + weapon.displayName);
        obj.transform.position = player.transform.position + new Vector3(1.05f, 0.36f, -0.2f);
        obj.transform.localScale = Vector3.one * GetWeaponScale(weapon);
        SpriteRenderer renderer = obj.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = 12;
        SphereCollider collider = obj.AddComponent<SphereCollider>();
        collider.isTrigger = true;
        collider.radius = 0.34f;

        WeaponPreviewEffect effect = obj.AddComponent<WeaponPreviewEffect>();
        effect.Initialize(GetWeaponVelocity(weapon), GetWeaponDuration(weapon), GetWeaponSpin(weapon), GetWeaponPulse(weapon), GetElementColor(weapon.element, 0.9f), weapon.basePower, weapon.displayName);
        weaponCooldownTimer = Mathf.Clamp(weapon.cooldown * 0.25f, 0.65f, 2.4f);
    }

    private void HighlightAltar(RogueRewardType? rewardType)
    {
        if (altarRenderer == null)
        {
            return;
        }

        if (!rewardType.HasValue)
        {
            altarRenderer.color = new Color(0.95f, 0.86f, 0.62f, 0.9f);
            return;
        }

        altarRenderer.color = rewardType.Value == RogueRewardType.Weapon
            ? new Color(1f, 0.42f, 0.12f, 1f)
            : new Color(0.25f, 0.52f, 1f, 1f);
    }

    private void OnGUI()
    {
        EnsureStyles();
        DrawMainPanel();
        DrawSlotPanel();
        DrawOperationStrip();

        if (showingOffer)
        {
            DrawOfferPanel();
        }
    }

    private void DrawMainPanel()
    {
        RoomConfig room = runState.GetCurrentRoom(catalog);
        GUILayout.BeginArea(new Rect(18, 16, 420, 244), panelStyle);
        GUILayout.Label("忍者秘境：影替试炼", titleStyle);
        GUILayout.Label("系统策划可运行原型 | 忍三肉鸽模式", bodyStyle);
        GUILayout.Space(6);
        GUILayout.Label($"进度：第 {runState.Chapter} 章 / 房间 {runState.RoomIndex}    已完成 {runState.CompletedRooms}", bodyStyle);
        if (room != null)
        {
            GUILayout.Label($"当前关卡：{room.displayName}  [{room.roomType}]  难度 {room.difficulty}", bodyStyle);
            GUILayout.Label($"障碍密度：{Mathf.RoundToInt(room.hazardDensity * 100f)}%    奖励节点：左右门 + 中央祭坛", bodyStyle);
        }

        GUILayout.Space(6);
        GUILayout.Label($"当前角色：{runState.CurrentCharacter?.displayName ?? "未配置"}", bodyStyle);
        GUILayout.Label($"当前武器：{runState.CurrentWeapon?.displayName ?? "未配置"}    冷却：{weaponCooldownTimer:0.0}s    当前身位：{(player != null && player.CurrentLane == 1 ? "上位" : "下位")}", bodyStyle);
        GUILayout.Label($"血量预算：{runState.EffectiveHp}    构筑评分：{runState.ComputePowerScore():0}", bodyStyle);
        GUILayout.Label($"协同：{runState.GetSynergySummary()}", bodyStyle);
        GUILayout.Label($"场内目标：{GetEnemySummary()}", bodyStyle);
        GUILayout.EndArea();
    }

    private void DrawSlotPanel()
    {
        GUILayout.BeginArea(new Rect(18, 270, 420, 388), panelStyle);
        GUILayout.Label("角色面板", titleStyle);
        foreach (CharacterConfig character in runState.CharacterSlots)
        {
            DrawCharacterSlot(character, character == runState.CurrentCharacter);
        }

        GUILayout.Space(8);
        GUILayout.Label("武器面板", titleStyle);
        foreach (WeaponConfig weapon in runState.WeaponSlots)
        {
            DrawWeaponSlot(weapon, weapon == runState.CurrentWeapon);
        }

        GUILayout.Space(8);
        GUILayout.Label("事件日志", titleStyle);
        foreach (string message in runState.EventLog)
        {
            GUILayout.Label("· " + message, tinyStyle);
        }

        GUILayout.EndArea();
    }

    private void DrawOperationStrip()
    {
        Rect rect = new Rect(Screen.width * 0.5f - 390f, Screen.height - 52f, 780f, 36f);
        GUI.Box(rect, "A/D 移动   W/S 单跑道上下切位   Space 跳跃   Shift 冲刺   Tab 切换角色   J 释放当前武器   E 进门   R 重开", bodyStyle);
    }

    private void DrawCharacterSlot(CharacterConfig character, bool current)
    {
        GUILayout.BeginHorizontal(cardStyle, GUILayout.Height(62));
        DrawTextureBox(LoadTexture($"ArtPlaceholders/Characters/{character.id}"), 44, 44);
        GUILayout.BeginVertical();
        GUILayout.Label((current ? "当前  " : "") + character.displayName, cardBodyTextStyle);
        GUILayout.Label($"{character.element} / {character.archetype}    HP {character.baseHp}    速度 {character.moveSpeed:0.0}", cardTinyTextStyle);
        GUILayout.Label(character.skill, cardTinyTextStyle);
        GUILayout.EndVertical();
        GUILayout.EndHorizontal();
    }

    private void DrawWeaponSlot(WeaponConfig weapon, bool current)
    {
        GUILayout.BeginHorizontal(cardStyle, GUILayout.Height(58));
        DrawTextureBox(LoadTexture($"ArtPlaceholders/Weapons/{weapon.id}"), 40, 40);
        GUILayout.BeginVertical();
        GUILayout.Label((current ? "当前  " : "") + weapon.displayName, cardBodyTextStyle);
        GUILayout.Label($"{weapon.rarity} / {weapon.element} / {weapon.role}    威力 {weapon.basePower}    CD {weapon.cooldown:0.0}s", cardTinyTextStyle);
        GUILayout.Label(weapon.effect, cardTinyTextStyle);
        GUILayout.EndVertical();
        GUILayout.EndHorizontal();
    }

    private void DrawOfferPanel()
    {
        Rect rect = new Rect(Screen.width * 0.5f - 390f, Screen.height * 0.5f - 210f, 780f, 420f);
        GUI.Box(rect, "", panelStyle);
        GUILayout.BeginArea(new Rect(rect.x + 24f, rect.y + 20f, rect.width - 48f, rect.height - 40f));
        GUILayout.Label(currentOfferType == RogueRewardType.Weapon ? "关底祭坛：武器奖励" : "关底祭坛：角色契印", titleStyle);
        GUILayout.Label("门只决定奖励池，真正结算在中央祭坛展开。按 1 / 2 / 3 选择，Esc 跳过。", bodyStyle);
        GUILayout.Space(12);

        GUILayout.BeginHorizontal();
        for (int i = 0; i < currentOffer.Count; i++)
        {
            DrawOfferCard(i, currentOffer[i]);
        }
        GUILayout.EndHorizontal();

        if (currentOffer.Count == 0)
        {
            GUILayout.Label("奖励池已空，按 Esc 继续下一关。", bodyStyle);
        }

        GUILayout.EndArea();
    }

    private void DrawOfferCard(int index, RewardOption option)
    {
        GUILayout.BeginVertical(cardStyle, GUILayout.Width(232), GUILayout.Height(265));
        GUILayout.Label($"{index + 1}", badgeStyle, GUILayout.Width(28));
        Texture2D icon = option.Type == RogueRewardType.Character
            ? LoadTexture($"ArtPlaceholders/Characters/{option.Character.id}")
            : LoadTexture($"ArtPlaceholders/Weapons/{option.Weapon.id}");
        DrawTextureBox(icon, 70, 70);
        GUILayout.Space(4);
        GUILayout.Label(option.Title, cardTitleTextStyle);
        GUILayout.Label(option.Subtitle, cardBodyTextStyle);
        GUILayout.Space(4);
        GUILayout.Label(option.Detail, cardTinyTextStyle);
        GUILayout.EndVertical();
    }

    private void DrawTextureBox(Texture2D texture, int width, int height)
    {
        Rect rect = GUILayoutUtility.GetRect(width, height, GUILayout.Width(width), GUILayout.Height(height));
        if (texture != null)
        {
            GUI.DrawTexture(rect, texture, ScaleMode.ScaleToFit, true);
        }
    }

    private Texture2D LoadTexture(string resourcePath)
    {
        if (textureCache.TryGetValue(resourcePath, out Texture2D cached))
        {
            return cached;
        }

        Texture2D texture = Resources.Load<Texture2D>(resourcePath);
        textureCache[resourcePath] = texture;
        return texture;
    }

    private string GetEnemySummary()
    {
        List<string> active = new List<string>();
        foreach (DemoEnemy enemy in enemies)
        {
            if (enemy != null && enemy.gameObject.activeInHierarchy)
            {
                active.Add($"{enemy.EnemyName} {enemy.Hp}/{enemy.MaxHp}");
            }
        }

        return active.Count == 0 ? "已清场" : string.Join("，", active);
    }

    private void EnsureStyles()
    {
        if (titleStyle != null)
        {
            return;
        }

        chineseFont = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "SimHei", "Arial Unicode MS", "Arial" }, 16);
        panelTexture = MakeGuiTexture(new Color(0.04f, 0.045f, 0.04f, 0.72f));
        cardTexture = MakeGuiTexture(new Color(0.95f, 0.88f, 0.68f, 0.82f));

        titleStyle = new GUIStyle(GUI.skin.label)
        {
            font = chineseFont,
            fontSize = 17,
            fontStyle = FontStyle.Bold,
            normal = { textColor = Color.white },
            wordWrap = true
        };

        bodyStyle = new GUIStyle(GUI.skin.label)
        {
            font = chineseFont,
            fontSize = 13,
            normal = { textColor = new Color(0.95f, 0.96f, 0.90f) },
            wordWrap = true
        };

        tinyStyle = new GUIStyle(bodyStyle)
        {
            fontSize = 11,
            normal = { textColor = new Color(0.88f, 0.90f, 0.84f) }
        };

        cardTitleTextStyle = new GUIStyle(titleStyle)
        {
            normal = { textColor = new Color(0.10f, 0.07f, 0.035f) }
        };

        cardBodyTextStyle = new GUIStyle(bodyStyle)
        {
            normal = { textColor = new Color(0.12f, 0.08f, 0.04f) }
        };

        cardTinyTextStyle = new GUIStyle(tinyStyle)
        {
            normal = { textColor = new Color(0.24f, 0.16f, 0.08f) }
        };

        panelStyle = new GUIStyle(GUI.skin.box)
        {
            font = chineseFont,
            normal = { background = panelTexture, textColor = Color.white },
            padding = new RectOffset(14, 14, 12, 12)
        };

        cardStyle = new GUIStyle(GUI.skin.box)
        {
            font = chineseFont,
            normal = { background = cardTexture, textColor = new Color(0.08f, 0.06f, 0.04f) },
            padding = new RectOffset(10, 10, 8, 8),
            margin = new RectOffset(4, 4, 4, 4)
        };

        badgeStyle = new GUIStyle(bodyStyle)
        {
            alignment = TextAnchor.MiddleCenter,
            normal = { textColor = Color.white }
        };
    }

    private static Texture2D MakeGuiTexture(Color color)
    {
        Texture2D texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        texture.SetPixel(0, 0, color);
        texture.Apply();
        return texture;
    }

    private static Color GetElementColor(string element, float alpha)
    {
        if (element == "火" || element == "Fire")
        {
            return new Color(1f, 0.28f, 0.08f, alpha);
        }

        if (element == "雷" || element == "Lightning")
        {
            return new Color(0.96f, 0.88f, 0.18f, alpha);
        }

        if (element == "水" || element == "Water")
        {
            return new Color(0.32f, 0.78f, 1f, alpha);
        }

        if (element == "风" || element == "Wind")
        {
            return new Color(0.38f, 1f, 0.55f, alpha);
        }

        if (element == "暗" || element == "Dark")
        {
            return new Color(0.58f, 0.24f, 0.95f, alpha);
        }

        return new Color(0.95f, 0.86f, 0.58f, alpha);
    }

    private static Color GetRoomTint(RoomConfig room)
    {
        if (room.roomType == "Boss")
        {
            return new Color(0.45f, 0.06f, 0.04f, 0.24f);
        }

        if (room.roomType == "Elite" || room.roomType == "精英")
        {
            return new Color(0.2f, 0.08f, 0.36f, 0.18f);
        }

        if (room.roomType == "Event" || room.roomType == "事件")
        {
            return new Color(0.08f, 0.28f, 0.34f, 0.16f);
        }

        return new Color(0.15f, 0.18f, 0.12f, 0.08f);
    }

    private static Color GetRoomHazardColor(RoomConfig room)
    {
        if (room.roomType == "Boss")
        {
            return new Color(0.95f, 0.05f, 0.03f, 0.95f);
        }

        if (room.roomType == "Elite" || room.roomType == "精英")
        {
            return new Color(0.7f, 0.08f, 0.95f, 0.9f);
        }

        return new Color(0.82f, 0.03f, 0.03f, 0.86f);
    }

    private static Vector3 GetWeaponVelocity(WeaponConfig weapon)
    {
        if (weapon.role == "爆发" || weapon.role == "Burst")
        {
            return new Vector3(6.2f, 0.2f, 0f);
        }

        if (weapon.role == "连击" || weapon.role == "Combo")
        {
            return new Vector3(8.5f, 0.55f, 0f);
        }

        if (weapon.role == "控制" || weapon.role == "Control")
        {
            return new Vector3(3.8f, 0f, 0f);
        }

        if (weapon.role == "机动" || weapon.role == "Mobility")
        {
            return new Vector3(7.2f, 1.05f, 0f);
        }

        if (weapon.role == "风险" || weapon.role == "Risk")
        {
            return new Vector3(9.2f, -0.2f, 0f);
        }

        return new Vector3(2.2f, 0f, 0f);
    }

    private static float GetWeaponScale(WeaponConfig weapon)
    {
        if (weapon.role == "爆发" || weapon.role == "Burst")
        {
            return 1.65f;
        }

        if (weapon.role == "控制" || weapon.role == "Control")
        {
            return 1.4f;
        }

        return 1.15f;
    }

    private static float GetWeaponDuration(WeaponConfig weapon)
    {
        return weapon.role == "支援" || weapon.role == "Support" ? 1.6f : 1.05f;
    }

    private static float GetWeaponSpin(WeaponConfig weapon)
    {
        if (weapon.role == "爆发" || weapon.role == "Burst")
        {
            return 420f;
        }

        if (weapon.role == "控制" || weapon.role == "Control")
        {
            return 90f;
        }

        return 220f;
    }

    private static float GetWeaponPulse(WeaponConfig weapon)
    {
        return weapon.role == "支援" || weapon.role == "Support" ? 0.45f : 0.2f;
    }
}
