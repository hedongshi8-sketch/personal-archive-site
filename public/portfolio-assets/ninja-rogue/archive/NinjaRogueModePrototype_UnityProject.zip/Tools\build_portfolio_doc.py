from pathlib import Path

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "Docs"
OUTPUT = ROOT / "Outputs" / "NinjaRogue_SystemPortfolio.docx"

DOC_ORDER = [
    "01_Idea_Pitch.md",
    "02_Game_Design_Proposal.md",
    "03_PRD.md",
    "04_Art_Request_Document.md",
    "05_Implementation_Plan.md",
    "06_Portfolio_Delivery_Guide.md",
    "07_Research_Notes.md",
    "08_Asset_Sources.md",
]


def set_run_font(run, size=10.5, bold=False, color=None):
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.font.bold = bold
    if color is not None:
        run.font.color.rgb = color


def configure_styles(doc):
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.12

    for name, size, color in [
        ("Heading 1", 16, RGBColor(11, 37, 69)),
        ("Heading 2", 13, RGBColor(31, 77, 120)),
        ("Heading 3", 11.5, RGBColor(46, 116, 181)),
    ]:
        style = styles[name]
        style.font.name = "Microsoft YaHei"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color


def set_cell_fill(cell, color_hex):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), color_hex)


def set_cell_text(cell, text, bold=False, fill=None):
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(str(text))
    set_run_font(run, size=9.2, bold=bold)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    if fill:
        set_cell_fill(cell, fill)


def add_table(doc, rows):
    rows = [row for row in rows if row]
    if not rows:
        return

    width = max(len(row) for row in rows)
    table = doc.add_table(rows=1, cols=width)
    table.style = "Table Grid"
    for index in range(width):
        set_cell_text(table.rows[0].cells[index], rows[0][index] if index < len(rows[0]) else "", bold=True, fill="E8EEF5")

    for row in rows[1:]:
        cells = table.add_row().cells
        for index in range(width):
            set_cell_text(cells[index], row[index] if index < len(row) else "")
    doc.add_paragraph()


def split_md_table_row(line):
    stripped = line.strip().strip("|")
    return [cell.strip().replace("`", "") for cell in stripped.split("|")]


def is_separator_row(line):
    text = line.replace("|", "").replace(":", "").replace("-", "").strip()
    return text == ""


def flush_table(doc, table_lines):
    if not table_lines:
        return
    rows = [split_md_table_row(line) for line in table_lines if not is_separator_row(line)]
    add_table(doc, rows)


def add_markdown_file(doc, path):
    lines = path.read_text(encoding="utf-8").splitlines()
    table_lines = []

    for raw in lines:
        line = raw.rstrip()
        if line.startswith("|"):
            table_lines.append(line)
            continue

        flush_table(doc, table_lines)
        table_lines = []

        if not line:
            continue

        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=1)
        elif line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=2)
        elif line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=3)
        elif line.startswith("- "):
            paragraph = doc.add_paragraph(style="List Bullet")
            run = paragraph.add_run(line[2:].strip().replace("`", ""))
            set_run_font(run)
        elif line[0:3].replace(".", "").isdigit() and ". " in line[:5]:
            paragraph = doc.add_paragraph(style="List Number")
            run = paragraph.add_run(line.split(". ", 1)[1].replace("`", ""))
            set_run_font(run)
        else:
            paragraph = doc.add_paragraph()
            run = paragraph.add_run(line.replace("`", ""))
            set_run_font(run)

    flush_table(doc, table_lines)


def build():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)
    configure_styles(doc)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("忍者秘境：影替试炼")
    set_run_font(run, size=22, bold=True, color=RGBColor(11, 37, 69))

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run("《忍者必须死3》限时肉鸽活动系统策划作品集")
    set_run_font(run, size=12, color=RGBColor(80, 80, 80))

    add_table(
        doc,
        [
            ["字段", "内容"],
            ["目标岗位", "杭州游戏中大厂系统策划秋招投递"],
            ["核心证明", "从点子提出到策划案、PRD、美术需求、配表、Unity demo、验证和投递包装的全流程能力"],
            ["Demo 当前状态", "中文 2D 横版水墨占位版：单跑道上下切位、角色/武器/关卡差分、左武器门、中央祭坛、右角色门、角色面板、武器试放"],
            ["素材边界", "不使用忍三或 Skul 商业素材；第三方相近占位素材保留来源与授权核验说明"],
        ],
    )

    doc.add_page_break()
    for index, file_name in enumerate(DOC_ORDER):
        path = DOCS / file_name
        if not path.exists():
            continue
        if index > 0:
            doc.add_page_break()
        add_markdown_file(doc, path)

    doc.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build()
