using UnityEngine;

public sealed class CameraFollow : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(5f, 1f, -10f);
    [SerializeField] private float smoothing = 8f;

    public void SetTarget(Transform value)
    {
        target = value;
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * smoothing);
        transform.rotation = GetComponent<Camera>() != null && GetComponent<Camera>().orthographic
            ? Quaternion.identity
            : Quaternion.Euler(55f, 0f, 0f);
    }
}
