using System;
using UnityEngine;

[Serializable]
public class NinjaRogueCatalog
{
    public string runName;
    public string version;
    public int chapterCount;
    public int roomsPerChapter;
    public int maxCharacterSlots;
    public int maxWeaponSlots;
    public int weaponOfferCount;
    public int characterOfferCount;
    public CharacterConfig[] characters;
    public WeaponConfig[] weapons;
    public RoomConfig[] rooms;
    public SynergyConfig[] synergies;

    public static NinjaRogueCatalog LoadDefault()
    {
        TextAsset asset = Resources.Load<TextAsset>("Config/ninja_rogue_catalog");
        if (asset == null)
        {
            Debug.LogWarning("Missing Resources/Config/ninja_rogue_catalog.json. Using fallback catalog.");
            return CreateFallback();
        }

        NinjaRogueCatalog catalog = JsonUtility.FromJson<NinjaRogueCatalog>(asset.text);
        if (catalog == null || catalog.characters == null || catalog.weapons == null)
        {
            Debug.LogWarning("Invalid catalog JSON. Using fallback catalog.");
            return CreateFallback();
        }

        return catalog;
    }

    private static NinjaRogueCatalog CreateFallback()
    {
        return new NinjaRogueCatalog
        {
            runName = "忍者秘境：影替试炼",
            version = "fallback",
            chapterCount = 2,
            roomsPerChapter = 4,
            maxCharacterSlots = 2,
            maxWeaponSlots = 3,
            weaponOfferCount = 3,
            characterOfferCount = 3,
            characters = new[]
            {
                new CharacterConfig
                {
                    id = "flame_runner",
                    displayName = "烈焰忍者",
                    element = "火",
                    archetype = "爆发",
                    baseHp = 110,
                    moveSpeed = 8.2f,
                    skill = "入场留下燃烧冲刺轨迹。",
                    portfolioPoint = "爆发角色差分。",
                    sourceMapping = "原创占位图。"
                }
            },
            weapons = new[]
            {
                new WeaponConfig
                {
                    id = "fire_wheel",
                    displayName = "火轮",
                    element = "火",
                    role = "爆发",
                    rarity = "稀有",
                    basePower = 46,
                    cooldown = 7f,
                    tags = "火,爆发",
                    effect = "试放大号旋转火轮。",
                    sourceMapping = "原创占位图。"
                }
            },
            rooms = new[]
            {
                new RoomConfig
                {
                    id = "lane_intro",
                    displayName = "秘境入口",
                    roomType = "战斗",
                    difficulty = 1,
                    length = 28f,
                    hazardDensity = 0.25f,
                    rewardNote = "教学左右门和中央祭坛。"
                }
            },
            synergies = Array.Empty<SynergyConfig>()
        };
    }
}

[Serializable]
public class CharacterConfig
{
    public string id;
    public string displayName;
    public string element;
    public string archetype;
    public int baseHp;
    public float moveSpeed;
    public string skill;
    public string portfolioPoint;
    public string sourceMapping;
}

[Serializable]
public class WeaponConfig
{
    public string id;
    public string displayName;
    public string element;
    public string role;
    public string rarity;
    public int basePower;
    public float cooldown;
    public string tags;
    public string effect;
    public string sourceMapping;
}

[Serializable]
public class RoomConfig
{
    public string id;
    public string displayName;
    public string roomType;
    public int difficulty;
    public float length;
    public float hazardDensity;
    public string rewardNote;
}

[Serializable]
public class SynergyConfig
{
    public string id;
    public string displayName;
    public string condition;
    public string effect;
    public string designerIntent;
}
