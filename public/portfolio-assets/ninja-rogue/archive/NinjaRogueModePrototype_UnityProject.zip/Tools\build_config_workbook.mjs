import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, "..");
const tablesDir = path.join(root, "Tables");
const outputDir = path.join(root, "Outputs");
const previewDir = path.join(outputDir, "WorkbookPreviews");

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];
    if (ch === '"' && inQuotes && next === '"') {
      cell += '"';
      i++;
    } else if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === "," && !inQuotes) {
      row.push(cell);
      cell = "";
    } else if ((ch === "\n" || ch === "\r") && !inQuotes) {
      if (ch === "\r" && next === "\n") {
        i++;
      }
      row.push(cell);
      if (row.some((value) => value.length > 0)) {
        rows.push(row);
      }
      row = [];
      cell = "";
    } else {
      cell += ch;
    }
  }

  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }

  return rows;
}

function toValues(rows) {
  return rows.map((row) =>
    row.map((value) => {
      if (/^-?\d+(\.\d+)?$/.test(value)) {
        return Number(value);
      }
      return value;
    }),
  );
}

function usedRange(rows) {
  const height = rows.length;
  const width = rows.reduce((max, row) => Math.max(max, row.length), 0);
  return { height, width };
}

function colLetter(index) {
  let value = index + 1;
  let letters = "";
  while (value > 0) {
    const mod = (value - 1) % 26;
    letters = String.fromCharCode(65 + mod) + letters;
    value = Math.floor((value - mod) / 26);
  }
  return letters;
}

function formatSheet(sheet, rows, tableName) {
  const { height, width } = usedRange(rows);
  const endCol = colLetter(width - 1);
  const range = sheet.getRange(`A1:${endCol}${height}`);
  range.format.font = { name: "Microsoft YaHei", size: 10, color: "#1F2937" };
  range.format.wrapText = true;
  range.format.borders = { preset: "outside", style: "thin", color: "#CBD5E1" };
  sheet.getRange(`A1:${endCol}1`).format = {
    fill: "#0F766E",
    font: { bold: true, color: "#FFFFFF", name: "Microsoft YaHei", size: 10 },
    wrapText: true,
  };
  sheet.getRange(`A1:${endCol}1`).format.borders = { preset: "all", style: "thin", color: "#0F766E" };
  range.format.autofitColumns();
  range.format.autofitRows();
  sheet.freezePanes.freezeRows(1);
  sheet.showGridLines = false;

  try {
    const table = sheet.tables.add(`A1:${endCol}${height}`, true, tableName);
    table.style = "TableStyleMedium2";
  } catch (error) {
    console.warn(`Skipping table style for ${tableName}: ${error.message}`);
  }
}

async function addCsvSheet(workbook, fileName, sheetName, tableName) {
  const text = await fs.readFile(path.join(tablesDir, fileName), "utf8");
  const rows = toValues(parseCsv(text));
  const sheet = workbook.worksheets.add(sheetName);
  const { height, width } = usedRange(rows);
  const endCol = colLetter(width - 1);
  sheet.getRange(`A1:${endCol}${height}`).values = rows;
  formatSheet(sheet, rows, tableName);
  return sheet;
}

async function build() {
  await fs.mkdir(outputDir, { recursive: true });
  await fs.mkdir(previewDir, { recursive: true });

  const workbook = Workbook.create();

  const overview = workbook.worksheets.add("Overview");
  overview.showGridLines = false;
  overview.getRange("A1:F1").merge();
  overview.getRange("A1").values = [["忍者秘境：影替试炼 - 配表总览"]];
  overview.getRange("A1").format = {
    fill: "#0B2545",
    font: { bold: true, color: "#FFFFFF", name: "Microsoft YaHei", size: 16 },
  };
  overview.getRange("A3:B8").values = [
    ["用途", "系统策划秋招作品集，证明从活动点子到可跑 demo 的全流程能力"],
    ["Demo", "Unity 2022.3.62f3c1；中文 2D 横版水墨占位场景；单跑道上下切位；左武器门 / 中央祭坛 / 右角色门；角色面板；武器试放；关卡差分"],
    ["配置源", "Assets/Resources/Config/ninja_rogue_catalog.json"],
    ["正式接入", "source_mapping 字段替换为授权角色、武器、图标和特效 ID"],
    ["版权边界", "不抓取忍三或 Skul 商业美术；第三方相近占位素材保留来源和授权核验说明"],
    ["核心循环", "跑小地图 -> 选择左武器门或右角色门 -> 中央祭坛三选一 -> 构筑成长 -> 章节验证"],
  ];
  overview.getRange("A3:B8").format = {
    font: { name: "Microsoft YaHei", size: 10, color: "#1F2937" },
    wrapText: true,
    borders: { preset: "outside", style: "thin", color: "#CBD5E1" },
  };
  overview.getRange("A3:A8").format = {
    fill: "#E8EEF5",
    font: { bold: true, color: "#0B2545", name: "Microsoft YaHei", size: 10 },
  };
  overview.getRange("A1:F8").format.autofitColumns();
  overview.getRange("A1:F8").format.autofitRows();

  await addCsvSheet(workbook, "characters.csv", "Characters", "CharactersTable");
  await addCsvSheet(workbook, "weapons.csv", "Weapons", "WeaponsTable");
  await addCsvSheet(workbook, "room_flow.csv", "RoomFlow", "RoomFlowTable");
  await addCsvSheet(workbook, "synergies.csv", "Synergies", "SynergiesTable");
  await addCsvSheet(workbook, "reward_rules.csv", "RewardRules", "RewardRulesTable");
  await addCsvSheet(workbook, "art_requests.csv", "ArtRequests", "ArtRequestsTable");
  await addCsvSheet(workbook, "milestones.csv", "Milestones", "MilestonesTable");

  const inspect = await workbook.inspect({
    kind: "sheet,table",
    maxChars: 4000,
    tableMaxRows: 3,
    tableMaxCols: 5,
  });
  console.log(inspect.ndjson);

  const previewSheets = ["Overview", "Characters", "Weapons", "RoomFlow", "RewardRules", "ArtRequests", "Milestones"];
  for (const sheetName of previewSheets) {
    const preview = await workbook.render({
      sheetName,
      autoCrop: "all",
      scale: 1,
      format: "png",
    });
    await fs.writeFile(path.join(previewDir, `${sheetName}.png`), new Uint8Array(await preview.arrayBuffer()));
  }

  const output = await SpreadsheetFile.exportXlsx(workbook);
  await output.save(path.join(outputDir, "NinjaRogue_ConfigWorkbook.xlsx"));
  console.log(path.join(outputDir, "NinjaRogue_ConfigWorkbook.xlsx"));
}

await build();
