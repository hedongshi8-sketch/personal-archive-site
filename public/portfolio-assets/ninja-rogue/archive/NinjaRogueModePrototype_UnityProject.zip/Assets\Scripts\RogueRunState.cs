using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public enum RogueRewardType
{
    Weapon,
    Character
}

public sealed class RewardOption
{
    public RogueRewardType Type;
    public CharacterConfig Character;
    public WeaponConfig Weapon;

    public string Title => Type == RogueRewardType.Character ? Character.displayName : Weapon.displayName;
    public string Subtitle => Type == RogueRewardType.Character
        ? $"{Character.element} / {Character.archetype}"
        : $"{Weapon.rarity} / {Weapon.element} / {Weapon.role}";
    public string Detail => Type == RogueRewardType.Character ? Character.skill : Weapon.effect;
}

public sealed class RogueRunState
{
    private System.Random random;

    public int Seed { get; private set; }
    public int Chapter { get; private set; }
    public int RoomIndex { get; private set; }
    public int CompletedRooms { get; private set; }
    public CharacterConfig CurrentCharacter { get; private set; }
    public List<CharacterConfig> CharacterSlots { get; } = new List<CharacterConfig>();
    public List<WeaponConfig> WeaponSlots { get; } = new List<WeaponConfig>();
    public List<string> EventLog { get; } = new List<string>();

    public int EffectiveHp => CharacterSlots.Sum(character => Mathf.Max(1, character.baseHp));
    public WeaponConfig CurrentWeapon => WeaponSlots.Count > 0 ? WeaponSlots[WeaponSlots.Count - 1] : null;

    public void Start(NinjaRogueCatalog catalog, int seed)
    {
        Seed = seed;
        random = new System.Random(seed);
        Chapter = 1;
        RoomIndex = 1;
        CompletedRooms = 0;
        CharacterSlots.Clear();
        WeaponSlots.Clear();
        EventLog.Clear();

        if (catalog.characters.Length > 0)
        {
            CurrentCharacter = catalog.characters[0];
            CharacterSlots.Add(CurrentCharacter);
        }

        if (catalog.weapons.Length > 0)
        {
            WeaponSlots.Add(catalog.weapons[0]);
        }

        AddLog($"随机种子 {seed}。初始角色：{CurrentCharacter?.displayName ?? "未配置"}。");
    }

    public RoomConfig GetCurrentRoom(NinjaRogueCatalog catalog)
    {
        if (catalog.rooms == null || catalog.rooms.Length == 0)
        {
            return null;
        }

        int chapterIndex = Mathf.Max(0, Chapter - 1);
        int roomIndex = Mathf.Max(0, RoomIndex - 1);
        int index = chapterIndex * Mathf.Max(1, catalog.roomsPerChapter) + roomIndex;
        if (index >= catalog.rooms.Length)
        {
            index = Mathf.Clamp(roomIndex, 0, catalog.rooms.Length - 1);
        }
        return catalog.rooms[index];
    }

    public List<RewardOption> GenerateOffer(NinjaRogueCatalog catalog, RogueRewardType rewardType)
    {
        int count = rewardType == RogueRewardType.Weapon ? catalog.weaponOfferCount : catalog.characterOfferCount;
        List<RewardOption> options = new List<RewardOption>();

        if (rewardType == RogueRewardType.Weapon)
        {
            List<RewardOption> pool = catalog.weapons
                .Where(weapon => WeaponSlots.All(owned => owned.id != weapon.id))
                .OrderBy(_ => random.Next())
                .Take(Mathf.Max(1, count))
                .Select(weapon => new RewardOption { Type = RogueRewardType.Weapon, Weapon = weapon })
                .ToList();
            options.AddRange(pool);
        }
        else
        {
            List<RewardOption> pool = catalog.characters
                .Where(character => CharacterSlots.All(owned => owned.id != character.id))
                .OrderBy(_ => random.Next())
                .Take(Mathf.Max(1, count))
                .Select(character => new RewardOption { Type = RogueRewardType.Character, Character = character })
                .ToList();
            options.AddRange(pool);
        }

        if (options.Count == 0)
        {
            AddLog(rewardType == RogueRewardType.Weapon ? "武器池已空，奖励转化为试炼币。" : "角色池已空，奖励转化为试炼币。");
        }

        return options;
    }

    public void ChooseReward(NinjaRogueCatalog catalog, RewardOption option)
    {
        if (option == null)
        {
            AddLog("跳过本次祭坛奖励。");
            Advance(catalog);
            return;
        }

        if (option.Type == RogueRewardType.Weapon)
        {
            if (WeaponSlots.Count >= catalog.maxWeaponSlots)
            {
                WeaponConfig removed = WeaponSlots[0];
                WeaponSlots.RemoveAt(0);
                AddLog($"武器槽已满，替换最早武器：{removed.displayName}。");
            }

            WeaponSlots.Add(option.Weapon);
            AddLog($"获得武器：{option.Weapon.displayName}。");
        }
        else
        {
            if (CharacterSlots.Count >= catalog.maxCharacterSlots)
            {
                CharacterConfig removed = CharacterSlots[0];
                CharacterSlots.RemoveAt(0);
                AddLog($"角色槽已满，替换最早角色：{removed.displayName}。");
            }

            CharacterSlots.Add(option.Character);
            CurrentCharacter = option.Character;
            AddLog($"契印切换：{option.Character.displayName} 入队并成为当前角色。");
        }

        Advance(catalog);
    }

    public void SwapCharacter()
    {
        if (CharacterSlots.Count < 2)
        {
            AddLog("当前只有 1 个角色契印，暂不能切换。");
            return;
        }

        int current = CharacterSlots.IndexOf(CurrentCharacter);
        int next = (current + 1) % CharacterSlots.Count;
        CurrentCharacter = CharacterSlots[next];
        AddLog($"手动切换角色：{CurrentCharacter.displayName}。");
    }

    public float ComputePowerScore()
    {
        float weaponScore = WeaponSlots.Sum(weapon => weapon.basePower * RarityMultiplier(weapon.rarity));
        float characterScore = CharacterSlots.Sum(character => character.baseHp * 0.08f + character.moveSpeed * 3f);
        return weaponScore + characterScore;
    }

    public string GetSynergySummary()
    {
        Dictionary<string, int> elementCounts = new Dictionary<string, int>();
        foreach (CharacterConfig character in CharacterSlots)
        {
            AddCount(elementCounts, character.element);
            AddCount(elementCounts, character.archetype);
        }

        foreach (WeaponConfig weapon in WeaponSlots)
        {
            AddCount(elementCounts, weapon.element);
            AddCount(elementCounts, weapon.role);
            foreach (string tag in SplitTags(weapon.tags))
            {
                AddCount(elementCounts, tag);
            }
        }

        List<string> active = elementCounts
            .Where(pair => pair.Value >= 2)
            .OrderByDescending(pair => pair.Value)
            .Select(pair => $"{pair.Key} x{pair.Value}")
            .Take(4)
            .ToList();

        return active.Count > 0 ? string.Join("，", active) : "暂无 2 件协同";
    }

    private void Advance(NinjaRogueCatalog catalog)
    {
        CompletedRooms++;
        RoomIndex++;
        if (RoomIndex > catalog.roomsPerChapter)
        {
            Chapter++;
            RoomIndex = 1;
            AddLog($"进入第 {Chapter} 章。");
        }

        if (Chapter > catalog.chapterCount)
        {
            AddLog("原型通关，循环回到第 1 章继续测试。");
            Chapter = 1;
            RoomIndex = 1;
        }
    }

    private void AddLog(string message)
    {
        EventLog.Insert(0, message);
        while (EventLog.Count > 7)
        {
            EventLog.RemoveAt(EventLog.Count - 1);
        }
    }

    private static float RarityMultiplier(string rarity)
    {
        if (string.Equals(rarity, "Epic", StringComparison.OrdinalIgnoreCase) || rarity == "史诗")
        {
            return 1.25f;
        }

        if (string.Equals(rarity, "Legendary", StringComparison.OrdinalIgnoreCase) || rarity == "传说")
        {
            return 1.55f;
        }

        return 1f;
    }

    private static IEnumerable<string> SplitTags(string tags)
    {
        if (string.IsNullOrWhiteSpace(tags))
        {
            yield break;
        }

        string[] parts = tags.Split(',');
        foreach (string part in parts)
        {
            string trimmed = part.Trim();
            if (!string.IsNullOrEmpty(trimmed))
            {
                yield return trimmed;
            }
        }
    }

    private static void AddCount(Dictionary<string, int> dictionary, string key)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return;
        }

        if (!dictionary.ContainsKey(key))
        {
            dictionary[key] = 0;
        }

        dictionary[key]++;
    }
}
