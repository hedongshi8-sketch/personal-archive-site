using UnityEngine;

public sealed class DemoEnemy : MonoBehaviour
{
    [SerializeField] private string enemyName = "小怪";
    [SerializeField] private int maxHp = 90;
    [SerializeField] private float bobAmplitude = 0.18f;
    [SerializeField] private float bobSpeed = 2.4f;

    private int hp;
    private Vector3 startPosition;
    private SpriteRenderer spriteRenderer;
    private Color baseColor;

    public string EnemyName => enemyName;
    public int Hp => Mathf.Max(0, hp);
    public int MaxHp => maxHp;

    public void Configure(string displayName, int health)
    {
        enemyName = displayName;
        maxHp = Mathf.Max(1, health);
        hp = maxHp;
    }

    public void ResetEnemy(Vector3 position, int health)
    {
        transform.position = position;
        startPosition = position;
        maxHp = Mathf.Max(1, health);
        hp = maxHp;
        gameObject.SetActive(true);
        if (spriteRenderer != null)
        {
            spriteRenderer.color = baseColor;
        }
    }

    public void TakeHit(int damage, string weaponName)
    {
        hp -= Mathf.Max(1, damage);
        if (spriteRenderer != null)
        {
            spriteRenderer.color = new Color(1f, 0.35f, 0.25f, 1f);
        }

        if (hp <= 0)
        {
            gameObject.SetActive(false);
        }
    }

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        baseColor = spriteRenderer != null ? spriteRenderer.color : Color.white;
        hp = maxHp;
        startPosition = transform.position;
    }

    private void Update()
    {
        transform.position = startPosition + Vector3.up * Mathf.Sin(Time.time * bobSpeed + transform.GetSiblingIndex()) * bobAmplitude;
        if (spriteRenderer != null)
        {
            spriteRenderer.color = Color.Lerp(spriteRenderer.color, baseColor, Time.deltaTime * 6f);
        }
    }
}
