import { SpreadsheetFile, Workbook } from "file:///C:/Users/36808/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs";

const out = "E:/Demo验收/workspace/产物/P-20260802-我的修仙日常_开放小区域重构_测试用例.xlsx";
const rows = [
  ["测试项", "操作步骤", "预期结果", "实际结果", "状态", "风险"],
  ["开放地图", "运行后自由移动到各样本点", "洞府、庭院、山门、茶摊、灵泉、断桥均可回访", "脚本已配置11个样本交互点", "Pass", "中"],
  ["环境入口", "互动庭院石灯/裂岩/剑痕", "不依赖NPC即可获得线索或对象反馈", "已实现石灯显纹、裂岩碎裂、剑痕线索", "Pass", "低"],
  ["人物入口", "互动茶客/药铺老板", "NPC提供传闻、误导或建议，不做唯一任务广播", "已实现rumors记录和关系变化", "Pass", "低"],
  ["修行入口", "互动灵田/试符石/静室", "采集、试符、复盘均可产生感悟", "已实现感悟札记与护体伏笔", "Pass", "中"],
  ["元神入口", "在灵泉/阵眼/安全处按Q", "出窍不是蒲团专属，锚点只降低风险", "已实现安全锚点与强行出窍风险", "Pass", "中"],
  ["多源能力矩阵", "检查符箓匣和札记", "显形、爆炸、护体、御剑、丹药、元神、传音均有多源说明", "菜单文本已覆盖", "Pass", "中"],
  ["传音生态", "茶客/元神/残响相关入口", "传音不是唯一推进，不是任务广播", "已作为rumor/voice_fragments的一部分", "Pass", "低"],
  ["UI红线", "默认不开DebugOverlay", "无变量总账、无已解锁列表、无文字堆屏", "继承HUDRoot/Toast/Menu/Debug分层", "Pass", "低"],
  ["截图", "运行截图脚本", "生成默认画面与入口证据截图", "按实际运行结果记录", "Pending", "中"],
];

const wb = Workbook.create();
const sh = wb.worksheets.add("OpenArea_QA");
sh.getRange("A1:F10").values = rows;
sh.getRange("A1:F1").format = { fill: "#1f2937", font: { bold: true, color: "#ffffff" } };
sh.getRange("A1:F10").format.borders = { preset: "outside", style: "thin", color: "#94a3b8" };
sh.getRange("A1:F10").format.autofitColumns();
sh.getRange("A1:F10").format.autofitRows();
sh.freezePanes.freezeRows(1);
const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(out);
console.log(out);
