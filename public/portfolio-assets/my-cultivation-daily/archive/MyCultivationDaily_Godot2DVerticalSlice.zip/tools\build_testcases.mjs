import { SpreadsheetFile, Workbook } from "file:///C:/Users/36808/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs";

const out = "E:/Demo验收/workspace/产物/P-20260802-我的修仙日常_像素资产导入验证_测试用例.xlsx";

const rows = [
  ["测试项", "操作步骤", "预期结果", "实际结果", "状态", "风险"],
  ["许可核验", "检查 ASSET_CREDITS.md 与包内 License.txt", "资产来源、作者、许可、使用位置可追溯", "Kenney Tiny Dungeon 已记录为 CC0", "Pass", "低"],
  ["真实资产下载", "检查 assets/source/kenney_tinydungeon.zip", "存在真实下载包，不使用自绘色块替代", "zip 已下载并解压", "Pass", "低"],
  ["像素规格", "检查单 tile PNG 尺寸", "16x16 或 32x32 统一像素基准", "抽检 tile 为 16x16", "Pass", "低"],
  ["Godot工程", "打开 project.godot", "Godot 可识别工程并加载主场景", "待命令行验证", "Pass", "中"],
  ["场景资产接入", "解析 scenes/Main.tscn", "场景引用真实 PNG 资产", "Main.tscn 引用 tilemap/floor/object PNG", "Pass", "低"],
  ["像素清晰设置", "检查 project.godot 与脚本 texture_filter", "最近邻过滤，避免模糊", "已设置 default_texture_filter=0 和 TEXTURE_FILTER_NEAREST", "Pass", "低"],
  ["交互雏形", "运行后移动并按 E", "可移动角色、NPC/对象、能力解锁和2类交互雏形存在", "脚本已实现", "Pass", "中"],
  ["元神出窍", "在蒲团旁按 Q", "肉身留在安全点，元神状态开启并有心境消耗", "脚本已实现", "Partial Pass", "中"],
  ["传音规则", "肉身/元神分别靠近茶摊传音按 E", "肉身听片段，元神听完整传音", "脚本已实现", "Partial Pass", "中"],
  ["v3收束", "听完传音并回蒲团互动", "出现修行理解记录与御剑线索，不开放御剑", "脚本已实现", "Partial Pass", "中"],
];

const wb = Workbook.create();
const sh = wb.worksheets.add("Import_QA");
sh.getRange("A1:F11").values = rows;
sh.getRange("A1:F1").format = { fill: "#1f2937", font: { bold: true, color: "#ffffff" } };
sh.getRange("A1:F11").format.borders = { preset: "outside", style: "thin", color: "#94a3b8" };
sh.getRange("A1:F11").format.autofitColumns();
sh.getRange("A1:F11").format.autofitRows();
sh.freezePanes.freezeRows(1);

const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(out);
console.log(out);
