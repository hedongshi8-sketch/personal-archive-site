extends Node2D

@export var tilemap_texture: Texture2D
@export var floor_texture: Texture2D
@export var object_texture: Texture2D

const TILE := 32
const SPEED := 145.0
const MAP_W := 20
const MAP_H := 11
const ORIGIN := Vector2(56, 104)
const TOAST_TIME := 2.6
const SPIRIT_SAFE_DISTANCE := 210.0
const V6_DEFAULT_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_高级竖切Demo_默认画面.png"
const V6_SPIRIT_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_高级竖切Demo_元神传音.png"
const V6_MANIFEST_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_高级竖切Demo_显形前后.png"
const V6_BLAST_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_高级竖切Demo_爆炸前后.png"
const DEFAULT_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_开放小区域_默认画面截图.png"
const EVIDENCE_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_开放小区域_入口证据截图.png"

var player: Sprite2D
var camera: Camera2D
var ground_layer: Node2D
var transition_layer: Node2D
var path_layer: Node2D
var decor_layer: Node2D
var occlusion_layer: Node2D
var vfx_layer: Node2D
var hud_root: Control
var interaction_prompt: Label
var ability_slot: Label
var risk_hint: Label
var toast_root: Control
var toast_label: Label
var menu_root: Control
var menu_title: Label
var menu_body: Label
var debug_overlay: Control
var debug_state_label: Label

var player_pos := ORIGIN + Vector2(96, 96)
var body_anchor := Vector2.ZERO
var spirit_mode := false
var mind := 100
var herbs := 0
var stones := 0
var relation := 0
var current_ability := "观照"
var nearby := {}
var interactables := []
var toast_left := 0.0

var insights := {}
var talismans := {}
var rumors := []
var voice_fragments := []
var discovered_points := []
var scene_time := 0.0

func _ready() -> void:
	RenderingServer.set_default_clear_color(Color("#111827"))
	_build_layers()
	_build_camera()
	_build_map()
	_build_set_dressing()
	_build_actor()
	_build_interactables()
	_build_ui()
	_record_point("洞府静室")
	_show_toast("开放样本：可先观察、找人、试修行或出窍。")
	_refresh_ui()
	if "--capture-open-area" in OS.get_cmdline_args() or "--capture-open-area" in OS.get_cmdline_user_args():
		call_deferred("_capture_open_area_screenshots")

func _process(delta: float) -> void:
	scene_time += delta
	_update_scene_motion()
	if toast_left > 0.0:
		toast_left -= delta
		if toast_left <= 0.0:
			toast_root.visible = false
	if spirit_mode:
		var drift := int(player_pos.distance_to(body_anchor) / 90.0)
		if drift > 0:
			mind = max(0, mind - drift)
		if mind <= 45 or player_pos.distance_to(body_anchor) > SPIRIT_SAFE_DISTANCE:
			_force_return_spirit("心神被肉身拉回。")

	var dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if Input.is_key_pressed(KEY_A):
		dir.x -= 1
	if Input.is_key_pressed(KEY_D):
		dir.x += 1
	if Input.is_key_pressed(KEY_W):
		dir.y -= 1
	if Input.is_key_pressed(KEY_S):
		dir.y += 1
	if dir != Vector2.ZERO:
		player_pos += dir.normalized() * SPEED * delta
		player_pos.x = clamp(player_pos.x, ORIGIN.x + 16, ORIGIN.x + MAP_W * TILE - 16)
		player_pos.y = clamp(player_pos.y, ORIGIN.y + 16, ORIGIN.y + MAP_H * TILE - 16)
		player.position = player_pos
		_update_nearby()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_E:
				_interact()
			KEY_Q:
				_toggle_spirit()
			KEY_F3:
				debug_overlay.visible = not debug_overlay.visible
				_refresh_ui()
			KEY_J:
				_open_menu("修行札记", _journal_text())
			KEY_T:
				_open_menu("符箓匣", _talisman_text())
			KEY_I:
				_open_menu("行囊", _inventory_text())
			KEY_M:
				_open_menu("地图", _map_text())
			KEY_L:
				_open_menu("关系录 / 传音札", _relation_text())
			KEY_ESCAPE:
				menu_root.visible = false
			KEY_R:
				if debug_overlay.visible:
					_reset()

func _build_layers() -> void:
	ground_layer = _make_layer("GroundLayer", -30)
	transition_layer = _make_layer("TransitionLayer", -20)
	path_layer = _make_layer("PathLayer", -10)
	decor_layer = _make_layer("DecorLayer", 0)
	occlusion_layer = _make_layer("OcclusionYSortLayer", 8)
	vfx_layer = _make_layer("VFXLayer", 12)

func _make_layer(layer_name: String, z: int) -> Node2D:
	var layer := Node2D.new()
	layer.name = layer_name
	layer.z_index = z
	add_child(layer)
	return layer

func _build_camera() -> void:
	camera = Camera2D.new()
	camera.name = "Camera2D_FramedOpenArea"
	camera.position = Vector2(468, 284)
	camera.zoom = Vector2(1.0, 1.0)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 4.0
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = 960
	camera.limit_bottom = 540
	add_child(camera)
	camera.make_current()

func _build_map() -> void:
	for y in MAP_H:
		for x in MAP_W:
			var tile := Sprite2D.new()
			tile.texture = floor_texture
			tile.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			tile.position = ORIGIN + Vector2(x * TILE, y * TILE)
			tile.scale = Vector2(2, 2)
			if x < 5 and y < 4:
				tile.modulate = Color("#b7a57a")
			elif x > 13 and y < 5:
				tile.modulate = Color("#87a96b")
			elif y > 7:
				tile.modulate = Color("#7c91ad")
			elif x > 8 and y > 3:
				tile.modulate = Color("#8fa977")
			ground_layer.add_child(tile)

func _build_set_dressing() -> void:
	for pos in [Vector2(156, 248), Vector2(204, 248), Vector2(252, 264), Vector2(300, 280), Vector2(348, 296), Vector2(396, 312), Vector2(444, 312), Vector2(492, 300), Vector2(540, 288), Vector2(588, 276), Vector2(636, 264), Vector2(684, 258), Vector2(732, 252)]:
		_add_set_piece("main_path", 0, pos, Vector2(2.2, 2.2), Color("#a27654"), path_layer, 0.0)
	for pos in [Vector2(104, 150), Vector2(128, 198), Vector2(190, 170), Vector2(232, 214), Vector2(344, 146), Vector2(398, 178), Vector2(612, 150), Vector2(650, 202), Vector2(760, 218), Vector2(826, 258), Vector2(438, 382), Vector2(806, 410)]:
		_add_set_piece("edge_grass", 72, pos, Vector2(1.6, 1.6), Color("#789f62"), transition_layer, 0.6)
	_add_set_piece("cave_lantern", 20, Vector2(126, 158), Vector2(2.1, 2.1), Color("#ffd67a"), vfx_layer, 1.2)
	_add_set_piece("courtyard_lamp", 20, Vector2(248, 154), Vector2(2.0, 2.0), Color("#f7e6a1"), vfx_layer, 1.5)
	_add_set_piece("mountain_gate", 56, Vector2(540, 154), Vector2(2.3, 2.3), Color("#9fb5d1"), decor_layer, 0.4)
	_add_set_piece("spirit_spring_aura", 24, Vector2(788, 236), Vector2(2.4, 2.4), Color("#9dd9ff"), vfx_layer, 2.0)
	_add_set_piece("array_rune_a", 60, Vector2(410, 390), Vector2(1.8, 1.8), Color("#c4b5fd"), vfx_layer, 2.4)
	_add_set_piece("array_rune_b", 60, Vector2(458, 410), Vector2(1.5, 1.5), Color("#a78bfa"), vfx_layer, 2.8)
	_add_set_piece("bridge_shadow", 40, Vector2(784, 390), Vector2(2.5, 2.5), Color("#8e9bb0"), decor_layer, 0.0)
	_add_set_piece("foreground_roof", 16, Vector2(112, 96), Vector2(4.6, 1.4), Color("#513022"), occlusion_layer, 0.0)
	_add_set_piece("foreground_tree", 72, Vector2(868, 334), Vector2(2.8, 2.8), Color("#4e7b50"), occlusion_layer, 1.0)

func _add_set_piece(name: String, tile_index: int, pos: Vector2, scale: Vector2, tint: Color, parent: Node2D, float_amp: float) -> void:
	var prop := Sprite2D.new()
	prop.name = name
	prop.texture = _tile_texture(tile_index)
	prop.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	prop.position = pos
	prop.scale = scale
	prop.modulate = tint
	prop.set_meta("base_pos", pos)
	prop.set_meta("base_scale", scale)
	prop.set_meta("float_amp", float_amp)
	prop.set_meta("phase", float(parent.get_child_count()) * 0.61)
	parent.add_child(prop)

func _update_scene_motion() -> void:
	_update_set_piece_motion(vfx_layer)
	_update_set_piece_motion(transition_layer)
	if camera:
		var target := player_pos + Vector2(120, 24)
		camera.position = camera.position.lerp(target, 1.0 - exp(-5.0 * get_process_delta_time()))
	for item in interactables:
		var sprite: Sprite2D = item["sprite"]
		var phase := float(item.get("phase", 0.0))
		var amp := float(item.get("float_amp", 0.0))
		var scale_boost := 1.0 + sin(scene_time * 2.0 + phase) * 0.03
		sprite.position = item["pos"] + Vector2(0, sin(scene_time * 1.7 + phase) * amp)
		sprite.scale = _interactable_scale(item["kind"]) * scale_boost
	if player:
		player.position = player_pos + Vector2(0, sin(scene_time * 3.1) * 1.5)
		player.scale = Vector2(2, 2) * (1.0 + sin(scene_time * 2.6) * 0.02)

func _update_set_piece_motion(layer: Node2D) -> void:
	if layer == null:
		return
	for child in layer.get_children():
		if child is Sprite2D and child.has_meta("base_pos"):
			var base_pos: Vector2 = child.get_meta("base_pos")
			var base_scale: Vector2 = child.get_meta("base_scale")
			var amp := float(child.get_meta("float_amp"))
			var phase := float(child.get_meta("phase"))
			child.position = base_pos + Vector2(0, sin(scene_time * 1.35 + phase) * amp)
			child.scale = base_scale * (1.0 + sin(scene_time * 1.8 + phase) * 0.025)

func _build_actor() -> void:
	player = Sprite2D.new()
	player.name = "Player_ImportedPixelSprite"
	player.texture = object_texture
	player.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	player.position = player_pos
	player.scale = Vector2(2, 2)
	decor_layer.add_child(player)

func _build_interactables() -> void:
	_add_interactable("洞府静室", "quiet_room", "修行", Vector2(136, 168), true)
	_add_interactable("庭院石灯", "stone_lamp", "环境", Vector2(248, 176), true)
	_add_interactable("灵田药畦", "field", "修行", Vector2(320, 296), true)
	_add_interactable("山门裂岩", "cracked_rock", "环境", Vector2(480, 260), false)
	_add_interactable("风口剑痕", "sword_mark", "环境", Vector2(608, 174), true)
	_add_interactable("镇口茶客", "tea_guest", "人物", Vector2(672, 326), true)
	_add_interactable("药铺老板", "herbalist", "人物", Vector2(552, 374), true)
	_add_interactable("灵泉", "spirit_spring", "元神", Vector2(760, 254), true)
	_add_interactable("废阵阵眼", "array_eye", "元神", Vector2(424, 390), true)
	_add_interactable("断桥高台", "broken_bridge", "环境", Vector2(744, 404), false)
	_add_interactable("试符石", "trial_stone", "修行", Vector2(384, 166), true)

func _add_interactable(title: String, kind: String, entry: String, pos: Vector2, safe_anchor: bool) -> void:
	var sprite := Sprite2D.new()
	sprite.name = title
	sprite.texture = _interactable_texture(kind)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	sprite.position = pos
	sprite.scale = _interactable_scale(kind)
	sprite.modulate = _interactable_tint(kind)
	sprite.z_index = _interactable_z_index(kind)
	decor_layer.add_child(sprite)
	interactables.append({
		"title": title,
		"kind": kind,
		"entry": entry,
		"pos": pos,
		"safe_anchor": safe_anchor,
		"sprite": sprite,
		"phase": float(interactables.size()) * 0.83,
		"float_amp": _interactable_float_amp(kind)
	})

func _tile_texture(index: int) -> Texture2D:
	return load("res://assets/source/kenney_tinydungeon/Tiles/tile_%04d.png" % index)

func _interactable_texture(kind: String) -> Texture2D:
	match kind:
		"quiet_room":
			return _tile_texture(80)
		"stone_lamp":
			return _tile_texture(20)
		"field":
			return _tile_texture(72)
		"cracked_rock":
			return _tile_texture(40)
		"sword_mark":
			return _tile_texture(60)
		"tea_guest", "herbalist":
			return object_texture
		"spirit_spring":
			return _tile_texture(24)
		"array_eye":
			return _tile_texture(60)
		"broken_bridge":
			return _tile_texture(80)
		"trial_stone":
			return _tile_texture(40)
	return object_texture

func _interactable_scale(kind: String) -> Vector2:
	if kind == "tea_guest" or kind == "herbalist":
		return Vector2(2, 2)
	if kind == "broken_bridge" or kind == "quiet_room":
		return Vector2(2.5, 2.5)
	return Vector2(2, 2)

func _interactable_z_index(kind: String) -> int:
	match kind:
		"quiet_room", "broken_bridge":
			return 1
		"field", "cracked_rock", "trial_stone":
			return 2
		"stone_lamp", "sword_mark", "spirit_spring", "array_eye":
			return 3
		"tea_guest", "herbalist":
			return 4
	return 2

func _interactable_float_amp(kind: String) -> float:
	match kind:
		"tea_guest", "herbalist":
			return 1.2
		"spirit_spring", "array_eye", "stone_lamp":
			return 2.2
		"quiet_room":
			return 0.8
	return 1.4

func _interactable_tint(kind: String) -> Color:
	match kind:
		"quiet_room":
			return Color("#d6b16a")
		"stone_lamp":
			return Color("#f7e6a1")
		"field":
			return Color("#74d680")
		"cracked_rock":
			return Color("#9ca3af")
		"sword_mark":
			return Color("#bfdbfe")
		"tea_guest":
			return Color("#f7c59f")
		"herbalist":
			return Color("#a7f3d0")
		"spirit_spring":
			return Color("#93c5fd")
		"array_eye":
			return Color("#c4b5fd")
		"broken_bridge":
			return Color("#d6d3d1")
		"trial_stone":
			return Color("#fcd34d")
	return Color.WHITE

func _build_ui() -> void:
	var ui_layer := CanvasLayer.new()
	ui_layer.name = "UILayer"
	add_child(ui_layer)

	hud_root = Control.new()
	hud_root.name = "HUDRoot"
	ui_layer.add_child(hud_root)

	var hud_panel := Panel.new()
	hud_panel.position = Vector2(12, 12)
	hud_panel.size = Vector2(228, 72)
	hud_panel.modulate = Color(1, 1, 1, 0.78)
	hud_root.add_child(hud_panel)

	var footer_panel := Panel.new()
	footer_panel.position = Vector2(12, 474)
	footer_panel.size = Vector2(936, 46)
	footer_panel.modulate = Color(1, 1, 1, 0.68)
	hud_root.add_child(footer_panel)

	ability_slot = Label.new()
	ability_slot.name = "AbilitySlot"
	ability_slot.position = Vector2(24, 24)
	ability_slot.text = "观照"
	ability_slot.add_theme_font_size_override("font_size", 16)
	ability_slot.add_theme_color_override("font_color", Color("#fef3c7"))
	hud_root.add_child(ability_slot)

	risk_hint = Label.new()
	risk_hint.name = "RiskHint"
	risk_hint.position = Vector2(24, 52)
	risk_hint.add_theme_font_size_override("font_size", 15)
	risk_hint.add_theme_color_override("font_color", Color("#fecaca"))
	hud_root.add_child(risk_hint)

	interaction_prompt = Label.new()
	interaction_prompt.name = "InteractionPrompt"
	interaction_prompt.position = Vector2(24, 488)
	interaction_prompt.add_theme_font_size_override("font_size", 17)
	interaction_prompt.add_theme_color_override("font_color", Color("#a7f3d0"))
	hud_root.add_child(interaction_prompt)

	toast_root = Control.new()
	toast_root.name = "ToastRoot"
	toast_root.visible = false
	ui_layer.add_child(toast_root)
	toast_label = Label.new()
	toast_label.position = Vector2(272, 430)
	toast_label.add_theme_font_size_override("font_size", 16)
	toast_label.add_theme_color_override("font_color", Color("#fef9c3"))
	toast_root.add_child(toast_label)

	menu_root = Control.new()
	menu_root.name = "MenuRoot"
	menu_root.visible = false
	ui_layer.add_child(menu_root)
	var panel := Panel.new()
	panel.position = Vector2(170, 82)
	panel.size = Vector2(620, 348)
	menu_root.add_child(panel)
	menu_title = Label.new()
	menu_title.position = Vector2(204, 110)
	menu_title.add_theme_font_size_override("font_size", 22)
	menu_root.add_child(menu_title)
	menu_body = Label.new()
	menu_body.position = Vector2(204, 150)
	menu_body.size = Vector2(552, 230)
	menu_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_body.add_theme_font_size_override("font_size", 16)
	menu_root.add_child(menu_body)

	debug_overlay = Control.new()
	debug_overlay.name = "DebugOverlay"
	debug_overlay.visible = false
	ui_layer.add_child(debug_overlay)
	var debug_panel := Panel.new()
	debug_panel.position = Vector2(16, 78)
	debug_panel.size = Vector2(690, 170)
	debug_overlay.add_child(debug_panel)
	debug_state_label = Label.new()
	debug_state_label.name = "DebugStateLabel"
	debug_state_label.position = Vector2(28, 90)
	debug_state_label.add_theme_font_size_override("font_size", 14)
	debug_overlay.add_child(debug_state_label)

func _update_nearby() -> void:
	nearby = {}
	for item in interactables:
		if player_pos.distance_to(item["pos"]) <= 44:
			nearby = item
			break
	_refresh_ui()

func _interact() -> void:
	if nearby.is_empty():
		_show_toast("风里没有明确回应。")
		return
	_record_point(nearby["title"])
	match nearby["kind"]:
		"quiet_room":
			mind = min(100, mind + 20)
			_gain_insight("复盘", "静室让杂念沉下去，但新的理解来自你在外面的碰撞。")
			_show_toast("心神安定，旧闻可在札记里慢慢对照。")
		"stone_lamp":
			current_ability = "显形"
			talismans["显形符"] = "庭院石灯旁的气流让符意自行成形。"
			_gain_insight("环境入口", "石灯旁空气扭曲，灵脉未必藏在门后。")
			nearby["sprite"].modulate = Color("#8bff9d")
			_show_toast("石灯下浮出细小灵纹。")
		"field":
			herbs += 1
			_gain_insight("修行入口", "采药时药性相冲，失败也能指出规则边界。")
			_show_toast("灵草 +1，药性有些躁。")
		"cracked_rock":
			current_ability = "爆炸"
			talismans["爆炸符"] = "裂纹岩、旧爆符和试符失败都能指向爆破符理。"
			_gain_insight("环境入口", "岩缝里的灵气走向显示：这里可炸，但不必只有一条来路。")
			nearby["sprite"].modulate = Color("#6b7280")
			_show_toast("裂岩震开，碎石留在山路边。")
		"trial_stone":
			current_ability = "护体"
			talismans["护体符"] = "试符石反震时，旧符短燃成护体光。"
			_gain_insight("修行入口", "试错的反震让护体符自己亮了一瞬。")
			nearby["sprite"].modulate = Color("#fbbf24")
			_show_toast("旧符自动护住掌心。")
		"tea_guest":
			relation += 1
			rumors.append("茶客说风口有剑鸣，也可能只是酒后误听。")
			voice_fragments.append("断桥……风急……有人借剑气传话。")
			_show_toast("得到一条半真半假的茶摊传闻。")
		"herbalist":
			relation += 1
			rumors.append("药铺老板建议用感知丹试灵泉，别只等别人给答案。")
			_gain_insight("人物入口", "NPC不发布任务，只提供立场、交易和可能误导。")
			_show_toast("药铺老板递来试药建议。")
		"spirit_spring":
			current_ability = "元神"
			_gain_insight("元神入口", "灵泉是稳定锚点之一，不是唯一出窍地点。")
			_show_toast("泉边心神变轻，按 Q 可较稳出窍。")
		"array_eye":
			current_ability = "元神"
			_gain_insight("元神入口", "阵眼会放大残响，也会扰乱归路。")
			_show_toast("阵眼里有多层声音互相折回。")
		"broken_bridge":
			_gain_insight("御剑线索", "高台剑痕、风流和传闻都指向御剑，但本样本不开放飞行。")
			_show_toast("断桥风声像被剑锋切开。")
	_refresh_ui()

func _toggle_spirit() -> void:
	if spirit_mode:
		_force_return_spirit("元神归窍。")
		return
	var safe := _near_safe_anchor()
	body_anchor = player_pos
	spirit_mode = true
	current_ability = "元神"
	player.modulate = Color("#9bf6ff")
	mind = max(0, mind - (8 if safe else 22))
	if safe:
		_show_toast("锚点稳定，元神短时离体。")
	else:
		_show_toast("强行出窍，心境剧烈波动。")
	_gain_insight("元神入口", "出窍可在安全处尝试，锚点只降低风险。")
	_refresh_ui()

func _force_return_spirit(text: String) -> void:
	spirit_mode = false
	player.modulate = Color.WHITE
	player_pos = body_anchor if body_anchor != Vector2.ZERO else player_pos
	player.position = player_pos
	_show_toast(text)
	_refresh_ui()

func _near_safe_anchor() -> bool:
	if nearby.is_empty():
		return false
	return nearby.get("safe_anchor", false)

func _gain_insight(key: String, text: String) -> void:
	if not insights.has(key):
		insights[key] = text

func _record_point(text: String) -> void:
	if not discovered_points.has(text):
		discovered_points.append(text)

func _show_toast(text: String) -> void:
	toast_label.text = text
	toast_root.visible = true
	toast_left = TOAST_TIME

func _refresh_ui() -> void:
	ability_slot.text = current_ability
	interaction_prompt.text = "E观察/互动；Q出窍；J札记 T符匣 I行囊 M地图 L传音札" if nearby.is_empty() else "E：%s" % nearby["title"]
	risk_hint.text = "离体不稳，尽快找锚点或归窍。" if spirit_mode and mind <= 70 else ""
	if debug_overlay.visible:
		debug_state_label.text = "DebugOverlay(F3)\nspirit:%s | mind:%d | ability:%s | herbs:%d | stones:%d | relation:%d\ninsights:%s\nnearby:%s" % [
			spirit_mode,
			mind,
			current_ability,
			herbs,
			stones,
			relation,
			", ".join(insights.keys()),
			nearby.get("kind", "none")
		]

func _open_menu(title: String, body: String) -> void:
	menu_title.text = title
	menu_body.text = body + "\n\nEsc关闭。"
	menu_root.visible = true

func _journal_text() -> String:
	var rows := ["开放样本札记：理解可来自环境、人物、修行和元神，不要求固定顺序。"]
	for key in insights.keys():
		rows.append("%s：%s" % [key, insights[key]])
	return "\n".join(rows)

func _talisman_text() -> String:
	var rows := ["当前观照：%s" % current_ability]
	rows.append("显形：%s" % talismans.get("显形符", "可从石灯、空气墙或元神观察逐步理解。"))
	rows.append("爆炸：%s" % talismans.get("爆炸符", "可由裂岩、NPC旧符或试符误触指向。"))
	rows.append("护体：%s" % talismans.get("护体符", "受击、灵压或试符反震时可能显现。"))
	rows.append("御剑：高台、剑痕、风流、传闻均可埋线索，本样本不开放飞行。")
	return "\n".join(rows)

func _inventory_text() -> String:
	return "灵草：%d\n灵石：%d\n试药记录：药性会影响心境与感知。\n材料不是KPI，只在具体互动中产生意义。" % [herbs, stones]

func _map_text() -> String:
	var rows := ["已走过：%s" % (", ".join(discovered_points) if discovered_points.size() > 0 else "洞府静室")]
	rows.append("样本点：洞府/静室、庭院/灵田、山门裂岩、茶摊/药铺、断桥高台、灵泉/阵眼。")
	rows.append("地图不标唯一答案，只保留你观察到的异常。")
	return "\n".join(rows)

func _relation_text() -> String:
	var rows := ["人物不是任务广播机。"]
	for rumor in rumors:
		rows.append("传闻：%s" % rumor)
	for voice in voice_fragments:
		rows.append("残响：%s" % voice)
	if spirit_mode:
		rows.append("元神侧听：声音更清楚，但仍可能偏颇。")
	return "\n".join(rows)

func prepare_default_screenshot() -> void:
	debug_overlay.visible = false
	menu_root.visible = false
	nearby = {}
	current_ability = "观照"
	_refresh_ui()

func _capture_open_area_screenshots() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	prepare_default_screenshot()
	await RenderingServer.frame_post_draw
	var default_path := ProjectSettings.globalize_path(V6_DEFAULT_SCREENSHOT)
	var default_result := get_viewport().get_texture().get_image().save_png(default_path)
	print("default screenshot: %s result=%s" % [default_path, default_result])
	prepare_evidence_screenshot()
	await RenderingServer.frame_post_draw
	var evidence_path := ProjectSettings.globalize_path(V6_SPIRIT_SCREENSHOT)
	var evidence_result := get_viewport().get_texture().get_image().save_png(evidence_path)
	print("evidence screenshot: %s result=%s" % [evidence_path, evidence_result])
	prepare_manifest_screenshot()
	await RenderingServer.frame_post_draw
	var manifest_path := ProjectSettings.globalize_path(V6_MANIFEST_SCREENSHOT)
	var manifest_result := get_viewport().get_texture().get_image().save_png(manifest_path)
	print("manifest screenshot: %s result=%s" % [manifest_path, manifest_result])
	prepare_blast_screenshot()
	await RenderingServer.frame_post_draw
	var blast_path := ProjectSettings.globalize_path(V6_BLAST_SCREENSHOT)
	var blast_result := get_viewport().get_texture().get_image().save_png(blast_path)
	print("blast screenshot: %s result=%s" % [blast_path, blast_result])
	get_tree().quit(0 if default_result == OK and evidence_result == OK and manifest_result == OK and blast_result == OK else 1)

func prepare_manifest_screenshot() -> void:
	debug_overlay.visible = false
	menu_root.visible = false
	player_pos = Vector2(246, 176)
	player.position = player_pos
	current_ability = "manifest"
	_show_toast("manifest: lamp lines answer before any quest chain.")
	_refresh_ui()

func prepare_blast_screenshot() -> void:
	debug_overlay.visible = false
	menu_root.visible = false
	player_pos = Vector2(484, 250)
	player.position = player_pos
	current_ability = "blast"
	_show_toast("blast: cracked rock changes the world object, then records the clue.")
	_refresh_ui()

func prepare_evidence_screenshot() -> void:
	debug_overlay.visible = false
	menu_root.visible = false
	player_pos = Vector2(718, 254)
	player.position = player_pos
	_update_nearby()
	nearby = {"title": "灵泉", "kind": "spirit_spring", "entry": "元神", "pos": Vector2(760, 254), "safe_anchor": true}
	_show_toast("入口证据：灵泉、阵眼、茶客、裂岩都能先开始。")
	_refresh_ui()

func _reset() -> void:
	herbs = 0
	stones = 0
	relation = 0
	mind = 100
	spirit_mode = false
	body_anchor = Vector2.ZERO
	current_ability = "观照"
	insights.clear()
	talismans.clear()
	rumors.clear()
	voice_fragments.clear()
	discovered_points.clear()
	player_pos = ORIGIN + Vector2(96, 96)
	player.position = player_pos
	player.modulate = Color.WHITE
	_record_point("洞府静室")
	menu_root.visible = false
	_show_toast("开发重置完成。")
	_refresh_ui()
