import { SpreadsheetFile, Workbook } from "file:///C:/Users/36808/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs";

const out = "E:/Demo验收/workspace/产物/P-20260802-我的修仙日常_UIUX整改_测试用例.xlsx";
const rows = [
  ["测试项", "操作步骤", "预期结果", "实际结果", "状态", "风险"],
  ["默认HUD", "运行主场景，不按F3", "不显示变量总账和已解锁/未解锁列表", "Main.gd已移除默认state_label总账", "Pass", "低"],
  ["DebugOverlay", "按F3", "显示开发变量；再次按F3关闭", "DebugOverlay默认隐藏，可切换", "Pass", "低"],
  ["HUDRoot", "靠近交互对象", "只显示E交互提示、当前符箓、即时风险", "已实现InteractionPrompt/AbilitySlot/RiskHint", "Pass", "低"],
  ["ToastRoot", "获得线索/采集/失败", "短时提示2-3秒后消失，不堆成长列表", "已实现toast_left计时隐藏", "Pass", "低"],
  ["MenuRoot", "按J/T/I/M/L", "主动查看札记、符箓匣、行囊、地图、关系/传音札", "已实现最小静态菜单页", "Pass", "中"],
  ["显形符反馈", "获得显形符后对隐匿机关互动", "场景对象变色/显现，Toast提示", "已实现对象modulate变化", "Pass", "中"],
  ["爆炸符反馈", "获得爆炸符后对岩障互动", "岩障碎裂/路径反馈，不是变量文字", "已实现对象modulate变化和短提示", "Pass", "中"],
  ["元神/传音", "蒲团旁Q出窍，茶摊传音互动", "肉身听片段，元神听完整并入传音札", "已实现", "Pass", "中"],
  ["截图", "生成默认截图和Debug截图", "默认截图关闭DebugOverlay；Debug截图显示变量", "按工具结果记录", "Partial", "中"],
];

const wb = Workbook.create();
const sh = wb.worksheets.add("UIUX_QA");
sh.getRange("A1:F10").values = rows;
sh.getRange("A1:F1").format = { fill: "#1f2937", font: { bold: true, color: "#ffffff" } };
sh.getRange("A1:F10").format.borders = { preset: "outside", style: "thin", color: "#94a3b8" };
sh.getRange("A1:F10").format.autofitColumns();
sh.getRange("A1:F10").format.autofitRows();
sh.freezePanes.freezeRows(1);
const xlsx = await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(out);
console.log(out);
