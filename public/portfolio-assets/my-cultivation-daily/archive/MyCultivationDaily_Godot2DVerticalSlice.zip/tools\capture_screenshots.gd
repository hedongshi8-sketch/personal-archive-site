extends SceneTree

const DEFAULT_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_开放小区域_默认画面截图.png"
const EVIDENCE_SCREENSHOT := "res://../../产物/P-20260802-我的修仙日常_开放小区域_入口证据截图.png"

func _initialize() -> void:
	call_deferred("_capture")

func _capture() -> void:
	var packed_scene: PackedScene = load("res://scenes/Main.tscn")
	var scene: Node = packed_scene.instantiate()
	root.add_child(scene)
	await process_frame
	await process_frame
	if scene.has_method("prepare_default_screenshot"):
		scene.call("prepare_default_screenshot")
	await process_frame
	var img: Image = root.get_texture().get_image()
	var default_path := ProjectSettings.globalize_path(DEFAULT_SCREENSHOT)
	var default_result := img.save_png(default_path)
	print("default screenshot: %s result=%s" % [default_path, default_result])
	if scene.has_method("prepare_evidence_screenshot"):
		scene.call("prepare_evidence_screenshot")
	await process_frame
	await process_frame
	var evidence_img: Image = root.get_texture().get_image()
	var evidence_path := ProjectSettings.globalize_path(EVIDENCE_SCREENSHOT)
	var evidence_result := evidence_img.save_png(evidence_path)
	print("evidence screenshot: %s result=%s" % [evidence_path, evidence_result])
	quit(0 if default_result == OK and evidence_result == OK else 1)
